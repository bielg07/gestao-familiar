// --- DADOS INICIAIS (MOCK) ---
let atividades = [
    { id: 'a1', titulo: "Natação Enzo", categoria: "esporte", start: new Date().toISOString().split('T')[0] + "T10:00" },
    { id: 'a2', titulo: "Reunião Pais", categoria: "escolar", start: new Date().toISOString().split('T')[0] + "T19:00" }
];

let membros = [
    { id: 'm1', nome: "Ricardo", papel: "Pai", cor: "#3b82f6" },
    { id: 'm2', nome: "Julia", papel: "Mãe", cor: "#ec4899" }
];

let calendar;

// --- INICIALIZAÇÃO ---
document.addEventListener('DOMContentLoaded', () => {
    atualizarDashboard();
    renderizarMembros();
    initCalendar();
});

// --- CONTROLE DE ABAS ---
function mudarTab(tabName, btn) {
    // Esconde todas
    document.querySelectorAll('.tab-content').forEach(t => t.classList.add('hidden'));
    document.querySelectorAll('.menu-item').forEach(m => m.classList.remove('active'));
    
    // Mostra atual
    document.getElementById(`tab-${tabName}`).classList.remove('hidden');
    btn.classList.add('active');
    
    // Título da página
    const titulos = { 'dashboard': 'Visão Geral', 'calendario': 'Agenda', 'membros': 'Gestão Familiar' };
    document.getElementById('page-title').innerText = titulos[tabName];

    // Bugfix FullCalendar (precisa redimensionar quando aparece)
    if(tabName === 'calendario' && calendar) {
        setTimeout(() => calendar.updateSize(), 200);
    }
}

// --- CALENDÁRIO ---
function initCalendar() {
    const calendarEl = document.getElementById('calendar');
    calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        locale: 'pt-br',
        height: 600,
        headerToolbar: { left: 'prev,next', center: 'title', right: 'dayGridMonth,listWeek' },
        events: gerarEventos(),
        eventClick: function(info) {
            abrirModalAtividade(info.event.id);
        }
    });
    calendar.render();
}

function gerarEventos() {
    return atividades.map(a => ({
        id: a.id,
        title: a.titulo,
        start: a.start,
        backgroundColor: getCor(a.categoria),
        borderColor: getCor(a.categoria)
    }));
}

// --- CRUD: ATIVIDADES ---
function abrirModalAtividade(idParaEditar = null) {
    document.getElementById('modal-overlay').classList.remove('hidden');
    document.getElementById('modal-atividade').classList.remove('hidden');
    document.getElementById('modal-membro').classList.add('hidden');

    const form = document.querySelector('#modal-atividade form');
    const btnDel = document.getElementById('btn-delete-ativ');

    if(idParaEditar) {
        // MODO EDIÇÃO
        const item = atividades.find(a => a.id === idParaEditar);
        document.getElementById('ativ-id').value = item.id;
        document.getElementById('ativ-titulo').value = item.titulo;
        document.getElementById('ativ-categoria').value = item.categoria;
        document.getElementById('ativ-data').value = item.start;
        btnDel.classList.remove('hidden'); 
    } else {
        // MODO CRIAÇÃO
        form.reset();
        document.getElementById('ativ-id').value = '';
        btnDel.classList.add('hidden');
    }
}

function salvarAtividade(e) {
    e.preventDefault();
    const id = document.getElementById('ativ-id').value;
    const titulo = document.getElementById('ativ-titulo').value;
    const cat = document.getElementById('ativ-categoria').value;
    const data = document.getElementById('ativ-data').value;

    if(id) {
        // Atualiza
        const index = atividades.findIndex(a => a.id === id);
        if(index > -1) atividades[index] = { id, titulo, categoria: cat, start: data };
    } else {
        // Cria novo
        atividades.push({ id: 'a'+Date.now(), titulo, categoria: cat, start: data });
    }
    
    fecharModais();
    atualizarDashboard();
    calendar.removeAllEvents();
    calendar.addEventSource(gerarEventos());
}

function excluirAtividade() {
    const id = document.getElementById('ativ-id').value;
    if(confirm('Tem certeza que deseja excluir esta atividade?')) {
        atividades = atividades.filter(a => a.id !== id);
        fecharModais();
        atualizarDashboard();
        calendar.removeAllEvents();
        calendar.addEventSource(gerarEventos());
    }
}

// --- CRUD: MEMBROS ---
function renderizarMembros() {
    const container = document.getElementById('lista-membros-ui');
    container.innerHTML = '';

    membros.forEach(m => {
        const card = document.createElement('div');
        card.className = 'member-card';
        card.innerHTML = `
            <div class="member-avatar-large" style="background:${m.cor}">${m.nome[0]}</div>
            <div>
                <h3>${m.nome}</h3>
                <span style="color:#888">${m.papel}</span>
            </div>
            <div class="member-actions">
                <button class="btn-action" onclick="editarMembro('${m.id}')"><i class="ph ph-pencil-simple"></i></button>
                <button class="btn-action delete" onclick="excluirMembro('${m.id}')"><i class="ph ph-trash"></i></button>
            </div>
        `;
        container.appendChild(card);
    });
}

function abrirModalMembro() {
    document.getElementById('modal-overlay').classList.remove('hidden');
    document.getElementById('modal-membro').classList.remove('hidden');
    document.getElementById('modal-atividade').classList.add('hidden');
    
    document.getElementById('membro-id').value = '';
    document.getElementById('membro-nome').value = '';
    document.getElementById('membro-papel').value = '';
}

function editarMembro(id) {
    const m = membros.find(x => x.id === id);
    abrirModalMembro();
    document.getElementById('membro-id').value = m.id;
    document.getElementById('membro-nome').value = m.nome;
    document.getElementById('membro-papel').value = m.papel;
    document.getElementById('membro-cor').value = m.cor;
}

function salvarMembro(e) {
    e.preventDefault();
    const id = document.getElementById('membro-id').value;
    const nome = document.getElementById('membro-nome').value;
    const papel = document.getElementById('membro-papel').value;
    const cor = document.getElementById('membro-cor').value;

    if(id) {
        const index = membros.findIndex(x => x.id === id);
        membros[index] = { id, nome, papel, cor };
    } else {
        membros.push({ id: 'm'+Date.now(), nome, papel, cor });
    }
    renderizarMembros();
    fecharModais();
}

function excluirMembro(id) {
    if(confirm('Remover este membro da família?')) {
        membros = membros.filter(x => x.id !== id);
        renderizarMembros();
    }
}

// --- UTILS ---
function fecharModais() {
    document.getElementById('modal-overlay').classList.add('hidden');
}

function atualizarDashboard() {
    // Contadores
    document.getElementById('dash-escolar').innerText = atividades.filter(a => a.categoria === 'escolar').length;
    document.getElementById('dash-esporte').innerText = atividades.filter(a => a.categoria === 'esporte').length;
    document.getElementById('dash-social').innerText = atividades.filter(a => a.categoria === 'social').length;

    // Lista Recente
    const lista = document.getElementById('lista-recentes');
    lista.innerHTML = '';
    atividades.slice(-4).reverse().forEach(a => {
        lista.innerHTML += `
            <li>
                <span><span class="dot ${getCorNome(a.categoria)}"></span> ${a.titulo}</span>
                <small>${new Date(a.start).toLocaleDateString('pt-BR')}</small>
            </li>`;
    });
}

function getCor(cat) {
    if(cat === 'escolar') return '#3b82f6';
    if(cat === 'esporte') return '#10b981';
    return '#ec4899';
}

function getCorNome(cat) {
    if(cat === 'escolar') return 'blue';
    if(cat === 'esporte') return 'green';
    return 'pink';
}