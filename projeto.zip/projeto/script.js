// script.js

document.addEventListener('DOMContentLoaded', function() {
    
    // 1. Configurar o Calendário (FullCalendar)
    var calendarEl = document.getElementById('calendar');
    
    // "dadosEventos" virá de uma variável global definida no index.php
    var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        locale: 'pt-br',
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,listWeek'
        },
        events: dadosEventos, // Aqui entram os dados do PHP
        eventClick: function(info) {
            alert('Evento: ' + info.event.title + '\nResponsável: ' + info.event.extendedProps.membro);
        }
    });
    
    calendar.render();

    // 2. Sistema de Notificações
    verificarCompromissosHoje(dadosEventos);
});

function verificarCompromissosHoje(eventos) {
    const hoje = new Date().toISOString().split('T')[0]; // Pega data YYYY-MM-DD
    
    eventos.forEach(evento => {
        // O formato do FullCalendar é "YYYY-MM-DDTHH:mm:ss" ou só "YYYY-MM-DD"
        let dataEvento = evento.start.split('T')[0];
        
        if (dataEvento === hoje) {
            mostrarNotificacao(`🔔 Hoje: ${evento.titulo} (${evento.membro})`);
        }
    });
}

function mostrarNotificacao(texto) {
    const container = document.getElementById('notification-area');
    
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.innerText = texto;
    
    container.appendChild(toast);
    
    // Animação de entrada
    setTimeout(() => { toast.classList.add('show'); }, 100);
    
    // Remover depois de 5 segundos
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => { toast.remove(); }, 500);
    }, 5000);
}