<?php
// backend.php
session_start();

// --- 1. SIMULANDO O BANCO DE DADOS ---
// Se não existir lista de membros, cria uma vazia
if (!isset($_SESSION['membros'])) {
    $_SESSION['membros'] = [
        ['id' => 1, 'nome' => 'Pai', 'cor' => '#3788d8'],
        ['id' => 2, 'nome' => 'Mãe', 'cor' => '#e83e8c']
    ];
}

// Se não existir lista de atividades, cria uma vazia (com 1 exemplo)
if (!isset($_SESSION['atividades'])) {
    $_SESSION['atividades'] = [
        [
            'titulo' => 'Reunião Escolar',
            'start' => date('Y-m-d').'T14:00:00', // Define para hoje às 14h
            'color' => '#3788d8',
            'membro' => 'Pai'
        ]
    ];
}

// --- 2. RECEBENDO DADOS DO FORMULÁRIO (POST) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Cadastro de Membro
    if (isset($_POST['acao']) && $_POST['acao'] === 'novo_membro') {
        $novo_membro = [
            'id' => count($_SESSION['membros']) + 1,
            'nome' => $_POST['nome'],
            'cor' => $_POST['cor']
        ];
        array_push($_SESSION['membros'], $novo_membro);
    }

    // Cadastro de Atividade
    if (isset($_POST['acao']) && $_POST['acao'] === 'nova_atividade') {
        // Busca o nome e cor do membro pelo ID
        $membro_id = $_POST['membro_id'];
        $membro_dados = null;
        foreach ($_SESSION['membros'] as $m) {
            if ($m['id'] == $membro_id) { $membro_dados = $m; break; }
        }

        if ($membro_dados) {
            $nova_atividade = [
                'titulo' => $_POST['titulo'],
                'start' => $_POST['data'],
                'color' => $membro_dados['cor'],
                'membro' => $membro_dados['nome']
            ];
            array_push($_SESSION['atividades'], $nova_atividade);
        }
    }

    // Redireciona para limpar o POST (padrão PRG)
    header("Location: index.php");
    exit;
}

// --- 3. EXPORTAR DADOS PARA O FRONTEND ---
$lista_membros = $_SESSION['membros'];
// Transforma o array PHP em JSON para o JavaScript ler
$json_eventos = json_encode($_SESSION['atividades']);
?>