<?php require 'backend.php'; ?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestão Familiar</title>
    <link rel="stylesheet" href="style.css">
    <script src='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.10/index.global.min.js'></script>
</head>
<body>

    <div id="notification-area" class="notification-container"></div>

    <div class="container">
        <div class="sidebar">
            <h2>👤 Membros</h2>
            <form action="index.php" method="POST">
                <input type="hidden" name="acao" value="novo_membro">
                <input type="text" name="nome" placeholder="Nome" required>
                <input type="color" name="cor" value="#3788d8" title="Cor da Agenda">
                <button type="submit">Adicionar</button>
            </form>

            <hr>

            <h2>📅 Nova Atividade</h2>
            <form action="index.php" method="POST">
                <input type="hidden" name="acao" value="nova_atividade">
                
                <select name="membro_id" required>
                    <option value="">Quem?</option>
                    <?php foreach($lista_membros as $membro): ?>
                        <option value="<?= $membro['id'] ?>"><?= $membro['nome'] ?></option>
                    <?php endforeach; ?>
                </select>

                <input type="text" name="titulo" placeholder="O que vai fazer?" required>
                <input type="datetime-local" name="data" required>
                <button type="submit">Agendar</button>
            </form>

            <div style="margin-top: 20px;">
                <small><strong>Legenda:</strong></small>
                <?php foreach($lista_membros as $m): ?>
                    <div style="margin-top:5px; display:flex; align-items:center;">
                        <span style="width:12px; height:12px; border-radius:50%; background:<?= $m['cor'] ?>; margin-right:8px;"></span>
                        <?= $m['nome'] ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="calendar-wrapper">
            <div id="calendar"></div>
        </div>
    </div>

    <script>
        // Esta variável recebe o JSON do PHP e fica disponível para o script.js
        const dadosEventos = <?php echo $json_eventos; ?>;
    </script>
    
    <script src="script.js"></script>

</body>
</html>