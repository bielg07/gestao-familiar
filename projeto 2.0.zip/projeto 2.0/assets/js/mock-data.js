// assets/js/mock-data.js

// 1. Dados iniciais simulados (O que viria do banco de dados)
const MOCK_MEMBROS = [
    { id: 1, nome: "Ricardo", cor: "#3b82f6" },
    { id: 2, nome: "Julia", cor: "#ec4899" },
    { id: 3, nome: "Enzo", cor: "#10b981" }
];

const MOCK_ATIVIDADES = [
    { 
        id: 101, 
        title: "Natação do Enzo", 
        start: new Date().toISOString().split('T')[0] + "T10:00:00", // Hoje às 10h
        membroId: 3,
        categoria: "Esporte"
    },
    { 
        id: 102, 
        title: "Reunião de Pais", 
        start: new Date().toISOString().split('T')[0] + "T19:00:00", // Hoje às 19h
        membroId: 1,
        categoria: "Escola"
    }
];