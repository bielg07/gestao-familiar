// --- ESTADO DA APLICAÇÃO (DADOS MOCKADOS) ---
let membros = [
    { id: 1, nome: "Ricardo", cor: "#3b82f6" },
    { id: 2, nome: "Julia", cor: "#ec4899" }
];

let atividades = [
    { id: 101, titulo: "Natação", inicio: new Date().toISOString().split('T')[0] + "T14:00", membroId: 1 },
    { id: 102, titulo: "Médico", inicio: new Date().toISOString().split('T')[0] + "T09:00", membroId: 2 }
];

let calendar; // Variável global do calendário

// --- INICIALIZAÇÃO ---
document.addEventListener('DOMContentLoaded', () => {
    renderizarMembros();
    iniciarCalendario();
    atualizarNotificacoes();
});

// --- FUNÇÕES DE MEMBROS ---

function renderizarMembros() {
    const lista = document.getElementById('lista-membros');
    const select = document.getElementById('select-membro');
    
    lista.innerHTML = '';
    select.innerHTML = '<option value="">Selecione...</option>';

    membros.forEach(m => {
        // 1. Preenche a Sidebar
        const li = document.createElement('li');
        li.className = 'member-item';
        li.innerHTML = `
            <div class="member-info">
                <span class="dot" style="background: ${m.cor}"></span>
                <span>${m.nome}</span>
            </div>
            <div class="member-actions">
                <button onclick="editarMembro(${m.id})"><i class="ph ph-pencil-simple"></i></button>
                <button onclick="excluirMembro(${m.id})"><i class="ph ph-trash" style="color:red"></i></button>
            </div>
        `;
        lista.appendChild(li);

        // 2. Preenche o Select do formulário de atividade
        const option = document.createElement('option');
        option.value = m.id;
        option.innerText = m.nome;
        select.appendChild(option);
    });
}

function salvarMembro(e) {
    e.preventDefault();
    const id = document.getElementById('membro-id').value;
    const nome = document.getElementById('nome-membro').value;
    const cor = document.getElementById('cor-membro').value;

    if (id) {
        // EDITAR
        const index = membros.findIndex(m => m.id == id);
        if (index > -1) {
            membros[index].nome = nome;
            membros[index].cor = cor;
        }
    } else {
        // NOVO
        membros.push({ id: Date.now(), nome, cor });
    }

    fecharModal();
    renderizarMembros();
    calendar.refetchEvents(); // Atualiza cores no calendário
}

function excluirMembro(id) {
    if (confirm("Tem certeza? Isso apagará as atividades dele também.")) {
        membros = membros.filter(m => m.id !== id);
        atividades = atividades.filter(a => a.membroId !== id); // Cascata
        renderizarMembros();
        calendar.refetchEvents();
        atualizarNotificacoes();
    }
}

function editarMembro(id) {
    const m = membros.find(m => m.id === id);
    if (m) {
        document.getElementById('membro-id').value = m.id;
        document.getElementById('nome-membro').value = m.nome;
        document.getElementById('cor-membro').value = m.cor;
        abrirModal('membro', true);
    }
}

// --- FUNÇÕES DE ATIVIDADES ---

function salvarAtividade(e) {
    e.preventDefault();
    const titulo = document.getElementById('titulo-atividade').value;
    const inicio = document.getElementById('data-atividade').value;
    const membroId = parseInt(document.getElementById('select-membro').value);

    // Adiciona ao array
    atividades.push({
        id: Date.now(),
        titulo,
        inicio,
        membroId
    });

    fecharModal();
    calendar.refetchEvents(); // Redesenha o calendário
    atualizarNotificacoes();
}

// --- CALENDÁRIO (FullCalendar) ---
function iniciarCalendario() {
    const calendarEl = document.getElementById('calendar');
    
    calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        locale: 'pt-br',
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,listWeek'
        },
        height: 'auto',
        
        // Função que alimenta o calendário com os dados do Array
        events: function(info, successCallback) {
            const eventosFormatados = atividades.map(a => {
                const dono = membros.find(m => m.id === a.membroId);
                return {
                    id: a.id,
                    title: a.titulo,
                    start: a.inicio,
                    backgroundColor: dono ? dono.cor : '#999',
                    borderColor: dono ? dono.cor : '#999'
                };
            });
            successCallback(eventosFormatados);
        },

        // Clique no evento para Excluir
        eventClick: function(info) {
            if(confirm(`Excluir a atividade "${info.event.title}"?`)) {
                // Remove do array pelo ID (que convertemos para string no calendário)
                atividades = atividades.filter(a => a.id != info.event.id);
                calendar.refetchEvents(); // Atualiza tela
                atualizarNotificacoes();
            }
        }
    });
    
    calendar.render();
}

// --- MODAIS E UI ---
function abrirModal(tipo, editando = false) {
    document.getElementById('modal-overlay').classList.remove('hidden');
    
    // Esconde todos forms e mostra só o certo
    document.getElementById('form-membro').classList.add('hidden');
    document.getElementById('form-atividade').classList.add('hidden');

    const titulo = document.getElementById('modal-titulo');

    if (tipo === 'membro') {
        document.getElementById('form-membro').classList.remove('hidden');
        titulo.innerText = editando ? "Editar Membro" : "Novo Membro";
        if (!editando) document.getElementById('form-membro').reset();
    } else {
        document.getElementById('form-atividade').classList.remove('hidden');
        titulo.innerText = "Nova Atividade";
        document.getElementById('form-atividade').reset();
    }
}

function fecharModal() {
    document.getElementById('modal-overlay').classList.add('hidden');
    document.getElementById('membro-id').value = ''; // Limpa ID de edição
}

function atualizarNotificacoes() {
    const hoje = new Date().toISOString().split('T')[0];
    const totalHoje = atividades.filter(a => a.inicio.startsWith(hoje)).length;
    document.getElementById('notif-count').innerText = totalHoje;
}