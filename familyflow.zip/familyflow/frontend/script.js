// ============================================
// FAMILYFLOW — Script Principal com API MySQL
// ============================================

// ─── CONFIGURAÇÃO DA API ───────────────────
// Aponte para onde seu backend PHP está rodando
const API_URL = 'http://localhost/familyflow/backend';

// Estado local (cache dos dados vindos da API)
let atividades = [];
let membros    = [];
let calendar;

// ─── TOKEN DE AUTENTICAÇÃO ────────────────
function getToken() {
    return localStorage.getItem('ff_token');
}

function setToken(token) {
    localStorage.setItem('ff_token', token);
}

function getUsuario() {
    const raw = localStorage.getItem('ff_usuario');
    return raw ? JSON.parse(raw) : null;
}

function setUsuario(user) {
    localStorage.setItem('ff_usuario', JSON.stringify(user));
}

// ─── HELPER: fetch autenticado ─────────────
async function api(path, options = {}) {
    const token = getToken();
    const res = await fetch(`${API_URL}${path}`, {
        ...options,
        headers: {
            'Content-Type': 'application/json',
            ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
            ...(options.headers || {}),
        },
        body: options.body ? JSON.stringify(options.body) : undefined,
    });

    // Sessão expirada → redireciona para login
    if (res.status === 401) {
        localStorage.clear();
        window.location.href = 'login.html';
        return;
    }

    const data = await res.json();

    if (!res.ok) {
        throw new Error(data.erro || 'Erro na requisição.');
    }

    return data;
}

// ─── VERIFICAÇÃO DE AUTENTICAÇÃO ──────────
function checarAuth() {
    if (!getToken()) {
        window.location.href = 'login.html';
    }
}

// ─── LOGOUT ───────────────────────────────
async function logout() {
    try {
        await api('/auth/logout', { method: 'POST' });
    } catch (_) {}
    localStorage.clear();
    window.location.href = 'login.html';
}

// ─── UTILS ────────────────────────────────
function hoje(offset = 0) {
    const d = new Date();
    d.setDate(d.getDate() + offset);
    return d.toISOString().split('T')[0];
}

function getCor(cat) {
    if (cat === 'escolar') return '#4f8ef7';
    if (cat === 'esporte') return '#34d399';
    return '#f06292';
}

function getCorNome(cat) {
    if (cat === 'escolar') return 'blue';
    if (cat === 'esporte') return 'green';
    return 'pink';
}

function capitalize(str) {
    if (!str) return '';
    return str.charAt(0).toUpperCase() + str.slice(1);
}

function statusText(status) {
    const map = {
        'pendente': 'Pendente',
        'em andamento': 'Em Andamento',
        'concluida': 'Concluída',
    };
    return map[status] || capitalize(status || 'pendente');
}

function formatarData(dataStr) {
    return new Date(dataStr + 'T12:00:00').toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' });
}

// Exibe spinner de carregamento genérico
function setLoading(elementId, on) {
    const el = document.getElementById(elementId);
    if (!el) return;
    if (on) {
        el.dataset.original = el.innerHTML;
        el.innerHTML = '<i class="ph ph-spinner" style="animation:spin 0.7s linear infinite;display:inline-block"></i>';
        el.disabled = true;
    } else {
        el.innerHTML = el.dataset.original || el.innerHTML;
        el.disabled = false;
    }
}

// Exibe erro amigável
function mostrarErroGlobal(msg) {
    pushNotif({ tipo: 'erro', icone: 'ph-warning', cor: 'urgente', titulo: 'Erro', desc: msg });
}

// ─── INIT ─────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
    checarAuth();

    // Atualiza data no header
    const headerDate = document.getElementById('header-date');
    if (headerDate) {
        headerDate.textContent = new Date().toLocaleDateString('pt-BR', {
            weekday: 'short', day: 'numeric', month: 'short', year: 'numeric'
        });
    }

    // Exibe nome do usuário logado na sidebar
    const usuario = getUsuario();
    if (usuario) {
        const userNameEl = document.querySelector('.user-name');
        if (userNameEl) userNameEl.textContent = usuario.nome;
        const avatarEl = document.querySelector('.avatar-small');
        if (avatarEl) avatarEl.textContent = usuario.nome[0].toUpperCase();
    }

    // Adiciona botão de logout no footer da sidebar
    const sidebarFooter = document.querySelector('.sidebar-footer');
    if (sidebarFooter) {
        const logoutBtn = document.createElement('button');
        logoutBtn.className = 'menu-item';
        logoutBtn.style.marginTop = '6px';
        logoutBtn.innerHTML = '<span class="menu-icon"><i class="ph ph-sign-out"></i></span><span>Sair</span>';
        logoutBtn.onclick = () => { if (confirm('Deseja sair?')) logout(); };
        sidebarFooter.appendChild(logoutBtn);
    }

    // Carrega dados da API em paralelo
    await carregarTudo();

    initCalendar();
    initNotificacoes();

    // Listeners de filtro — recarrega da API com filtros
    ['filter-nome', 'filter-status', 'filter-categoria', 'filter-membro', 'filter-data-inicio'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.addEventListener('input', () => renderizarAtividades());
    });
});

// Carrega membros e atividades do banco
async function carregarTudo() {
    try {
        [membros, atividades] = await Promise.all([
            api('/membros'),
            api('/atividades'),
        ]);
    } catch (e) {
        mostrarErroGlobal('Erro ao carregar dados: ' + e.message);
        membros = []; atividades = [];
    }

    renderizarMembros();
    renderizarAtividades();
    popularFiltroMembros();
    atualizarDashboard();
    atualizarCalendario();
    renderizarProximos7();
}

// ─── ABAS ─────────────────────────────────
function mudarTab(tabName, btn) {
    document.querySelectorAll('.tab-content').forEach(t => t.classList.add('hidden'));
    document.querySelectorAll('.menu-item').forEach(m => m.classList.remove('active'));
    document.getElementById(`tab-${tabName}`).classList.remove('hidden');
    btn.classList.add('active');

    const titulos = { dashboard: 'Visão Geral', calendario: 'Agenda', membros: 'Gestão Familiar', atividades: 'Atividades' };
    const breadcrumbs = { dashboard: 'Início', calendario: 'Início › Calendário', membros: 'Início › Membros', atividades: 'Início › Atividades' };
    document.getElementById('page-title').innerText = titulos[tabName];
    const bc = document.getElementById('breadcrumb');
    if (bc) bc.innerText = breadcrumbs[tabName];

    if (tabName === 'calendario' && calendar) {
        setTimeout(() => { calendar.updateSize(); renderizarProximos7(); }, 200);
    }
}

// ─── CALENDÁRIO ───────────────────────────
function initCalendar() {
    const calendarEl = document.getElementById('calendar');
    calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        locale: 'pt-br',
        height: 560,
        headerToolbar: { left: 'prev,next today', center: 'title', right: 'dayGridMonth,listWeek' },
        events: gerarEventos(),
        eventClick: info => abrirModalAtividade(info.event.id),
        dateClick: info => mostrarEventosDia(info.dateStr),
    });
    calendar.render();
    renderizarProximos7();
}

function gerarEventos() {
    return atividades.map(a => ({
        id: a.id,
        title: a.titulo,
        start: a.data + 'T' + a.hora,
        backgroundColor: getCor(a.categoria),
        borderColor: 'transparent',
        textColor: '#ffffff',
        extendedProps: { categoria: a.categoria, status: a.status },
    }));
}

function atualizarCalendario() {
    if (calendar) {
        calendar.removeAllEvents();
        calendar.addEventSource(gerarEventos());
    }
}

function mostrarEventosDia(dateStr) {
    const titleEl = document.getElementById('day-detail-title');
    const listEl  = document.getElementById('day-events-list');
    const date    = new Date(dateStr + 'T00:00:00');
    const formatted = date.toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' });
    titleEl.innerHTML = `<i class="ph ph-calendar-check"></i><span>${formatted}</span>`;

    const eventos = atividades.filter(a => a.data === dateStr).sort((a, b) => a.hora.localeCompare(b.hora));
    if (eventos.length === 0) { listEl.innerHTML = '<p class="empty-day">Nenhum evento neste dia.</p>'; return; }

    listEl.innerHTML = eventos.map(a => `
        <div class="day-event-item" onclick="abrirModalAtividade('${a.id}')">
            <div class="day-event-title">
                <span class="dot ${getCorNome(a.categoria)}" style="margin-right:6px;display:inline-block"></span>${a.titulo}
            </div>
            <div class="day-event-meta">
                <span>${a.hora}</span><span>·</span>
                <span class="status-badge ${(a.status||'pendente').replace(' ','-')}">${statusText(a.status)}</span>
            </div>
        </div>`).join('');
}

function renderizarProximos7() {
    const lista = document.getElementById('upcoming-7-list');
    if (!lista) return;
    const now = new Date(), futuro = new Date();
    futuro.setDate(futuro.getDate() + 7);

    const proximos = atividades
        .filter(a => { const d = new Date(a.data + 'T' + a.hora); return d >= now && d <= futuro; })
        .sort((a, b) => (a.data + a.hora).localeCompare(b.data + b.hora));

    if (proximos.length === 0) { lista.innerHTML = '<p class="empty-day">Nenhum evento nos próximos 7 dias.</p>'; return; }

    lista.innerHTML = proximos.map(a => {
        const d = new Date(a.data + 'T00:00:00');
        return `<div class="upcoming-item">
            <div class="upcoming-date">
                <div class="upcoming-day">${d.toLocaleDateString('pt-BR',{day:'2-digit'})}</div>
                <div class="upcoming-month">${d.toLocaleDateString('pt-BR',{month:'short'})}</div>
            </div>
            <div class="upcoming-info">
                <div class="upcoming-title">${a.titulo}</div>
                <div class="upcoming-cat">
                    <span class="dot ${getCorNome(a.categoria)}" style="display:inline-block;margin-right:4px"></span>
                    ${capitalize(a.categoria)} · ${a.hora}
                </div>
            </div>
        </div>`;
    }).join('');
}

// ─── CRUD: ATIVIDADES ─────────────────────
function abrirModalAtividade(idParaEditar = null) {
    document.getElementById('modal-overlay').classList.remove('hidden');
    document.getElementById('modal-atividade').classList.remove('hidden');
    document.getElementById('modal-membro').classList.add('hidden');

    const form   = document.querySelector('#modal-atividade form');
    const btnDel = document.getElementById('btn-delete-ativ');
    const title  = document.querySelector('#modal-atividade .modal-title');

    // Popula checkboxes de membros
    const listaMembros = document.getElementById('ativ-membros-list');
    listaMembros.innerHTML = '';
    membros.forEach(m => {
        listaMembros.innerHTML += `
            <label class="member-checkbox">
                <input type="checkbox" value="${m.id}" class="ativ-membro-check">
                <span class="member-chip" style="--chip-color:${m.cor}">
                    <span class="chip-avatar" style="background:${m.cor}">${m.nome[0]}</span>
                    ${m.nome}
                </span>
            </label>`;
    });

    if (idParaEditar) {
        const item = atividades.find(a => a.id == idParaEditar);
        if (!item) return;
        title.textContent = 'Editar Atividade';
        document.getElementById('ativ-id').value        = item.id;
        document.getElementById('ativ-titulo').value    = item.titulo;
        document.getElementById('ativ-descricao').value = item.descricao || '';
        document.getElementById('ativ-categoria').value = item.categoria;
        document.getElementById('ativ-status').value    = item.status || 'pendente';
        document.getElementById('ativ-data').value      = item.data;
        document.getElementById('ativ-hora').value      = item.hora;
        (item.membrosIds || []).forEach(mid => {
            const cb = listaMembros.querySelector(`input[value="${mid}"]`);
            if (cb) cb.checked = true;
        });
        btnDel.classList.remove('hidden');
    } else {
        title.textContent = 'Nova Atividade';
        form.reset();
        document.getElementById('ativ-id').value = '';
        btnDel.classList.add('hidden');
    }
}

async function salvarAtividade(e) {
    e.preventDefault();
    const id        = document.getElementById('ativ-id').value;
    const titulo    = document.getElementById('ativ-titulo').value;
    const descricao = document.getElementById('ativ-descricao').value;
    const categoria = document.getElementById('ativ-categoria').value;
    const status    = document.getElementById('ativ-status').value;
    const data      = document.getElementById('ativ-data').value;
    const hora      = document.getElementById('ativ-hora').value;
    const membrosIds = [...document.querySelectorAll('.ativ-membro-check:checked')].map(cb => cb.value);

    const payload = { titulo, descricao, categoria, status, data, hora, membrosIds };
    const btnSalvar = document.querySelector('#modal-atividade button[type="submit"]');
    setLoading(btnSalvar?.id, true);

    try {
        let salva;
        if (id) {
            salva = await api(`/atividades/${id}`, { method: 'PUT', body: payload });
            const idx = atividades.findIndex(a => a.id == id);
            if (idx > -1) atividades[idx] = salva;
            const membrosNomes = membrosIds.map(mid => membros.find(m => m.id == mid)?.nome).filter(Boolean);
            pushNotif({
                tipo: 'atividade-editada', icone: 'ph-pencil-simple', cor: 'breve',
                titulo: 'Atividade atualizada',
                desc: `"${titulo}" foi editada · ${capitalize(categoria)} · ${formatarData(data)} às ${hora}${membrosNomes.length ? ' · ' + membrosNomes.join(', ') : ''}`,
            });
        } else {
            salva = await api('/atividades', { method: 'POST', body: payload });
            atividades.push(salva);
            const membrosNomes = membrosIds.map(mid => membros.find(m => m.id == mid)?.nome).filter(Boolean);
            pushNotif({
                tipo: 'atividade-criada', icone: 'ph-plus-circle', cor: 'lembrete',
                titulo: 'Nova atividade criada',
                desc: `"${titulo}" · ${capitalize(categoria)} · ${formatarData(data)} às ${hora}${membrosNomes.length ? ' · Para: ' + membrosNomes.join(', ') : ''}`,
            });
        }

        fecharModais();
        renderizarAtividades();
        atualizarDashboard();
        atualizarCalendario();
        renderizarProximos7();
        verificarCompromissosProximos();

    } catch (err) {
        mostrarErroGlobal(err.message);
    } finally {
        if (btnSalvar) { btnSalvar.disabled = false; }
    }
}

async function excluirAtividade(id) {
    const idToDelete = id || document.getElementById('ativ-id').value;
    if (!confirm('Tem certeza que deseja excluir esta atividade?')) return;

    const atv = atividades.find(a => a.id == idToDelete);
    try {
        await api(`/atividades/${idToDelete}`, { method: 'DELETE' });
        atividades = atividades.filter(a => a.id != idToDelete);

        if (atv) {
            pushNotif({
                tipo: 'atividade-excluida', icone: 'ph-trash', cor: 'urgente',
                titulo: 'Atividade removida',
                desc: `"${atv.titulo}" foi excluída da agenda.`,
            });
        }

        fecharModais();
        renderizarAtividades();
        atualizarDashboard();
        atualizarCalendario();
        renderizarProximos7();
        verificarCompromissosProximos();

    } catch (err) {
        mostrarErroGlobal(err.message);
    }
}

// ─── FILTROS ──────────────────────────────
function getFilters() {
    return {
        nome:       (document.getElementById('filter-nome')?.value || '').toLowerCase().trim(),
        status:     document.getElementById('filter-status')?.value || '',
        categoria:  document.getElementById('filter-categoria')?.value || '',
        membro:     document.getElementById('filter-membro')?.value || '',
        dataInicio: document.getElementById('filter-data-inicio')?.value || '',
    };
}

function filtrarAtividades() {
    const f = getFilters();
    return atividades.filter(a => {
        if (f.nome      && !a.titulo.toLowerCase().includes(f.nome)) return false;
        if (f.status    && a.status    !== f.status)    return false;
        if (f.categoria && a.categoria !== f.categoria) return false;
        if (f.membro    && !(a.membrosIds || []).includes(f.membro)) return false;
        if (f.dataInicio && a.data < f.dataInicio)      return false;
        return true;
    });
}

function temFiltroAtivo() {
    const f = getFilters();
    return f.nome || f.status || f.categoria || f.membro || f.dataInicio;
}

function limparFiltros() {
    ['filter-nome','filter-status','filter-categoria','filter-membro','filter-data-inicio'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.value = '';
    });
    renderizarAtividades();
}

function popularFiltroMembros() {
    const select = document.getElementById('filter-membro');
    if (!select) return;
    const current = select.value;
    select.innerHTML = '<option value="">Membro: Todos</option>';
    membros.forEach(m => { select.innerHTML += `<option value="${m.id}">${m.nome}</option>`; });
    select.value = current;
}

// ─── RENDERIZAR ATIVIDADES ────────────────
function renderizarAtividades() {
    const container = document.getElementById('lista-atividades-ui');
    container.innerHTML = '';

    const filtradas = filtrarAtividades();
    const sorted    = [...filtradas].sort((a, b) => (a.data + a.hora).localeCompare(b.data + b.hora));

    const countEl = document.getElementById('atividades-count');
    if (countEl) {
        countEl.textContent = temFiltroAtivo()
            ? `${sorted.length} de ${atividades.length} atividade${atividades.length !== 1 ? 's' : ''}`
            : `${atividades.length} atividade${atividades.length !== 1 ? 's' : ''} cadastrada${atividades.length !== 1 ? 's' : ''}`;
    }

    const filterCount = document.getElementById('filter-count');
    if (filterCount) {
        filterCount.innerHTML = temFiltroAtivo()
            ? `<strong>${sorted.length}</strong> resultado${sorted.length !== 1 ? 's' : ''}`
            : '';
    }

    if (sorted.length === 0) {
        container.innerHTML = temFiltroAtivo()
            ? `<div class="empty-state"><i class="ph ph-magnifying-glass"></i><p>Nenhuma atividade encontrada</p><small>Tente ajustar os filtros</small></div>`
            : `<div class="empty-state"><i class="ph ph-list-checks"></i><p>Nenhuma atividade cadastrada</p><small>Clique em "Nova Atividade" para começar</small></div>`;
        return;
    }

    sorted.forEach(a => {
        const card = document.createElement('div');
        card.className = 'activity-card';
        const dataFormatada = new Date(a.data + 'T12:00:00').toLocaleDateString('pt-BR', { day: '2-digit', month: 'short', year: 'numeric' });
        const statusClass   = (a.status || 'pendente').replace(' ', '-');

        let membrosHtml = '';
        if (a.membrosIds?.length) {
            membrosHtml = '<div class="activity-members">';
            a.membrosIds.forEach(mid => {
                const m = membros.find(x => x.id == mid);
                if (m) membrosHtml += `<span class="mini-avatar" style="background:${m.cor}" title="${m.nome}">${m.nome[0]}</span>`;
            });
            membrosHtml += '</div>';
        }

        card.innerHTML = `
            <div class="activity-card-info">
                <span class="dot ${getCorNome(a.categoria)}"></span>
                <div style="min-width:0">
                    <h4>${a.titulo} <span class="status-badge ${statusClass}">${statusText(a.status)}</span></h4>
                    ${a.descricao ? `<p class="activity-desc">${a.descricao}</p>` : ''}
                    <div class="activity-meta">
                        <i class="ph ph-tag"></i> ${capitalize(a.categoria)}
                        &nbsp;·&nbsp;<i class="ph ph-calendar"></i> ${dataFormatada}
                        &nbsp;·&nbsp;<i class="ph ph-clock"></i> ${a.hora}
                    </div>
                    ${membrosHtml}
                </div>
            </div>
            <div class="member-actions">
                <button class="btn-action" onclick="abrirModalAtividade('${a.id}')" title="Editar"><i class="ph ph-pencil-simple"></i></button>
                <button class="btn-action delete" onclick="excluirAtividade('${a.id}')" title="Excluir"><i class="ph ph-trash"></i></button>
            </div>`;
        container.appendChild(card);
    });
}

// ─── CRUD: MEMBROS ────────────────────────
function renderizarMembros() {
    const container = document.getElementById('lista-membros-ui');
    container.innerHTML = '';

    const countEl = document.getElementById('membros-count');
    if (countEl) countEl.textContent = `${membros.length} membro${membros.length !== 1 ? 's' : ''} cadastrado${membros.length !== 1 ? 's' : ''}`;

    membros.forEach(m => {
        const qtd  = atividades.filter(a => (a.membrosIds || []).includes(m.id) || (a.membrosIds || []).includes(String(m.id))).length;
        const card = document.createElement('div');
        card.className = 'member-card';
        card.innerHTML = `
            <div class="member-avatar-large" style="background:${m.cor}">${m.nome[0]}</div>
            <div><h3>${m.nome}</h3><span class="member-role-text">${m.papel}</span></div>
            <span class="member-activity-count">${qtd} atividade${qtd !== 1 ? 's' : ''}</span>
            <div class="member-actions">
                <button class="btn-action" onclick="editarMembro('${m.id}')"><i class="ph ph-pencil-simple"></i></button>
                <button class="btn-action delete" onclick="excluirMembro('${m.id}')"><i class="ph ph-trash"></i></button>
            </div>`;
        container.appendChild(card);
    });
}

function abrirModalMembro() {
    document.getElementById('modal-overlay').classList.remove('hidden');
    document.getElementById('modal-membro').classList.remove('hidden');
    document.getElementById('modal-atividade').classList.add('hidden');
    document.querySelector('#modal-membro .modal-title').textContent = 'Novo Membro';
    document.getElementById('membro-id').value    = '';
    document.getElementById('membro-nome').value  = '';
    document.getElementById('membro-papel').value = '';
    document.getElementById('membro-cor').value   = '#4f8ef7';
}

function editarMembro(id) {
    const m = membros.find(x => x.id == id);
    if (!m) return;
    abrirModalMembro();
    document.querySelector('#modal-membro .modal-title').textContent = 'Editar Membro';
    document.getElementById('membro-id').value    = m.id;
    document.getElementById('membro-nome').value  = m.nome;
    document.getElementById('membro-papel').value = m.papel;
    document.getElementById('membro-cor').value   = m.cor;
}

async function salvarMembro(e) {
    e.preventDefault();
    const id    = document.getElementById('membro-id').value;
    const nome  = document.getElementById('membro-nome').value;
    const papel = document.getElementById('membro-papel').value;
    const cor   = document.getElementById('membro-cor').value;

    try {
        let salvo;
        if (id) {
            salvo = await api(`/membros/${id}`, { method: 'PUT', body: { nome, papel, cor } });
            const idx = membros.findIndex(x => x.id == id);
            if (idx > -1) membros[idx] = salvo;
            pushNotif({
                tipo: 'membro-editado', icone: 'ph-pencil-simple', cor: 'breve',
                titulo: 'Membro atualizado',
                desc: `${nome} (${papel}) teve seus dados atualizados.`,
            });
        } else {
            salvo = await api('/membros', { method: 'POST', body: { nome, papel, cor } });
            membros.push(salvo);
            pushNotif({
                tipo: 'membro-criado', icone: 'ph-user-plus', cor: 'lembrete',
                titulo: 'Novo membro adicionado',
                desc: `${nome} entrou como ${papel} na família. 👋`,
            });
        }

        renderizarMembros();
        popularFiltroMembros();
        atualizarDashboard();
        fecharModais();

    } catch (err) {
        mostrarErroGlobal(err.message);
    }
}

async function excluirMembro(id) {
    if (!confirm('Remover este membro da família?')) return;
    const m = membros.find(x => x.id == id);
    try {
        await api(`/membros/${id}`, { method: 'DELETE' });
        membros = membros.filter(x => x.id != id);
        if (m) {
            pushNotif({
                tipo: 'membro-excluido', icone: 'ph-user-minus', cor: 'urgente',
                titulo: 'Membro removido',
                desc: `${m.nome} (${m.papel}) foi removido da família.`,
            });
        }
        renderizarMembros();
        popularFiltroMembros();
        atualizarDashboard();
    } catch (err) {
        mostrarErroGlobal(err.message);
    }
}

// ─── DASHBOARD ────────────────────────────
function atualizarDashboard() {
    const escolar = atividades.filter(a => a.categoria === 'escolar').length;
    const esporte = atividades.filter(a => a.categoria === 'esporte').length;
    const social  = atividades.filter(a => a.categoria === 'social').length;
    const total   = atividades.length;

    document.getElementById('dash-escolar').innerText = escolar;
    document.getElementById('dash-esporte').innerText = esporte;
    document.getElementById('dash-social').innerText  = social;
    document.getElementById('dash-total').innerText   = total;

    if (total > 0) {
        document.getElementById('bar-escolar').style.width = (escolar / total * 100) + '%';
        document.getElementById('bar-social').style.width  = (social  / total * 100) + '%';
        document.getElementById('bar-esporte').style.width = (esporte / total * 100) + '%';
    }

    // Próximas atividades
    const lista = document.getElementById('lista-recentes');
    const proximas = [...atividades]
        .filter(a => a.data >= hoje(0) && a.status !== 'concluida')
        .sort((a, b) => (a.data + a.hora).localeCompare(b.data + b.hora))
        .slice(0, 5);

    lista.innerHTML = '';
    if (proximas.length === 0) {
        lista.innerHTML = '<li style="color:var(--text-3);font-size:0.82rem;text-align:center;padding:20px 0;">Nenhuma atividade futura.</li>';
    } else {
        proximas.forEach(a => {
            const df = new Date(a.data + 'T12:00:00').toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' });
            lista.innerHTML += `
                <li>
                    <div class="item-left">
                        <span class="dot ${getCorNome(a.categoria)}"></span>
                        <span class="item-title">${a.titulo}</span>
                    </div>
                    <span class="item-date">${df} · ${a.hora}</span>
                </li>`;
        });
    }

    // Membros
    const dashMembros = document.getElementById('dash-membros-list');
    if (dashMembros) {
        dashMembros.innerHTML = '';
        membros.forEach(m => {
            const qtd = atividades.filter(a => (a.membrosIds || []).map(String).includes(String(m.id))).length;
            dashMembros.innerHTML += `
                <div class="dash-member-row">
                    <div class="mini-avatar" style="background:${m.cor}">${m.nome[0]}</div>
                    <div>
                        <div class="member-name">${m.nome}</div>
                        <div class="member-role">${m.papel}</div>
                    </div>
                    <span class="member-count">${qtd} ativ.</span>
                </div>`;
        });
    }
}

// ─── MODAIS ───────────────────────────────
function fecharModais() {
    document.getElementById('modal-overlay').classList.add('hidden');
    document.getElementById('modal-atividade').classList.add('hidden');
    document.getElementById('modal-membro').classList.add('hidden');
}

function overlayClick(e) {
    if (e.target === document.getElementById('modal-overlay')) fecharModais();
}

document.addEventListener('keydown', e => { if (e.key === 'Escape') fecharModais(); });

// ============================================
// SISTEMA DE NOTIFICAÇÕES
// ============================================

let notificacoes = [];
let notifPanelAberto = false;
let toastContainer = null;
let compromissosJaNotificados = new Set();

function initNotificacoes() {
    // Evita criar container duplicado
    if (document.getElementById('notif-toast-container')) return;
    toastContainer = document.createElement('div');
    toastContainer.className = 'notif-toast-container';
    toastContainer.id = 'notif-toast-container';
    document.body.appendChild(toastContainer);

    document.addEventListener('click', (e) => {
        const wrapper = document.getElementById('notif-wrapper');
        if (wrapper && !wrapper.contains(e.target) && notifPanelAberto) fecharNotifPanel();
    });

    verificarCompromissosProximos();
    setInterval(verificarCompromissosProximos, 60000);
    renderizarNotificacoes();
}

function pushNotif({ tipo, icone, cor, titulo, desc }) {
    const notif = {
        id: 'n' + Date.now() + Math.random().toString(36).slice(2),
        tipo, icone, cor, titulo, desc,
        criadaEm: new Date(), lida: false, atividadeId: null,
    };
    notificacoes.unshift(notif);
    mostrarToast(notif);
    renderizarNotificacoes();
}

function verificarCompromissosProximos() {
    const agora  = new Date();
    const alertas = [
        { minutos: 30,   label: 'em 30 minutos', cor: 'urgente', icone: 'ph-warning-circle' },
        { minutos: 60,   label: 'em 1 hora',      cor: 'hoje',   icone: 'ph-clock' },
        { minutos: 1440, label: 'amanhã',          cor: 'breve',  icone: 'ph-calendar-check' },
        { minutos: 4320, label: 'em 3 dias',       cor: 'lembrete',icone: 'ph-bell' },
    ];
    const cfg = {
        30:   document.getElementById('alerta-30min')?.checked ?? true,
        60:   document.getElementById('alerta-1h')?.checked   ?? true,
        1440: document.getElementById('alerta-1d')?.checked   ?? true,
        4320: document.getElementById('alerta-3d')?.checked   ?? false,
    };

    atividades.forEach(a => {
        if (a.status === 'concluida') return;
        const dataAtiv = new Date(a.data + 'T' + a.hora);
        const diffMin  = (dataAtiv - agora) / 60000;
        if (diffMin < 0 || diffMin > 4320) return;

        alertas.forEach(al => {
            if (!cfg[al.minutos] || diffMin > al.minutos) return;
            const chave = `${a.id}_${al.minutos}`;
            if (compromissosJaNotificados.has(chave)) return;
            compromissosJaNotificados.add(chave);

            const membrosNomes = (a.membrosIds || [])
                .map(mid => membros.find(m => m.id == mid)?.nome).filter(Boolean).join(', ');

            const notif = {
                id: 'n' + Date.now() + Math.random().toString(36).slice(2),
                tipo: 'compromisso', icone: al.icone, cor: al.cor,
                titulo: `⏰ ${a.titulo}`,
                desc: `${capitalize(a.categoria)} · ${formatarData(a.data)} às ${a.hora} — ${al.label}${membrosNomes ? ' · ' + membrosNomes : ''}`,
                criadaEm: new Date(), lida: false, atividadeId: a.id,
            };
            notificacoes.unshift(notif);
            if (al.minutos <= 60) mostrarToast(notif);
            if (Notification.permission === 'granted') {
                new Notification(`⏰ ${a.titulo}`, { body: notif.desc });
            }
        });
    });
    renderizarNotificacoes();
}

function renderizarNotificacoes() {
    const lista  = document.getElementById('notif-list');
    const badge  = document.getElementById('notif-badge');
    const btn    = document.getElementById('notif-btn');
    if (!lista) return;

    const naoLidas = notificacoes.filter(n => !n.lida).length;
    if (naoLidas > 0) {
        badge.textContent = naoLidas > 9 ? '9+' : naoLidas;
        badge.classList.remove('hidden');
        btn.classList.add('has-unread');
    } else {
        badge.classList.add('hidden');
        btn.classList.remove('has-unread');
    }

    if (notificacoes.length === 0) {
        lista.innerHTML = `<div class="notif-empty"><i class="ph ph-bell-slash"></i>Nenhuma notificação ainda.</div>`;
        return;
    }

    lista.innerHTML = notificacoes.map(n => `
        <div class="notif-item ${n.cor} ${n.lida ? '' : 'unread'}" onclick="clicarNotif('${n.id}')">
            <div class="notif-icon-wrap"><i class="ph ${n.icone}"></i></div>
            <div class="notif-content">
                <div class="notif-title">${n.titulo}</div>
                <div class="notif-desc">${n.desc}</div>
                <div class="notif-time"><i class="ph ph-clock"></i> ${formatarTempoNotif(n.criadaEm)}</div>
            </div>
            ${!n.lida ? '<div class="notif-unread-dot"></div>' : ''}
        </div>`).join('');
}

function clicarNotif(id) {
    const notif = notificacoes.find(n => n.id === id);
    if (!notif) return;
    notif.lida = true;
    renderizarNotificacoes();
    fecharNotifPanel();
    if (notif.atividadeId) abrirModalAtividade(notif.atividadeId);
}

function marcarTodasLidas()  { notificacoes.forEach(n => n.lida = true); renderizarNotificacoes(); }
function limparTodasNotif()  { notificacoes = []; renderizarNotificacoes(); }
function toggleNotifPanel()  { notifPanelAberto ? fecharNotifPanel() : abrirNotifPanel(); }

function abrirNotifPanel() {
    document.getElementById('notif-panel').classList.remove('hidden');
    notifPanelAberto = true;
    renderizarNotificacoes();
}

function fecharNotifPanel() {
    document.getElementById('notif-panel')?.classList.add('hidden');
    document.getElementById('notif-config')?.classList.add('hidden');
    notifPanelAberto = false;
}

function toggleNotifConfig() { document.getElementById('notif-config').classList.toggle('hidden'); }

function mostrarToast(notif) {
    if (!toastContainer) return;
    const duracao = 5000;
    const toast = document.createElement('div');
    toast.className = 'notif-toast';
    toast.innerHTML = `
        <div class="toast-icon ${notif.cor}"><i class="ph ${notif.icone}"></i></div>
        <div class="toast-body">
            <div class="toast-title">${notif.titulo}</div>
            <div class="toast-desc">${notif.desc}</div>
        </div>
        <button class="toast-close" onclick="fecharToast(this.closest('.notif-toast'))"><i class="ph ph-x"></i></button>
        <div class="toast-progress ${notif.cor}" style="width:100%"></div>`;
    toastContainer.appendChild(toast);
    const bar = toast.querySelector('.toast-progress');
    requestAnimationFrame(() => { bar.style.transition = `width ${duracao}ms linear`; bar.style.width = '0%'; });
    setTimeout(() => fecharToast(toast), duracao);
}

function fecharToast(toast) {
    if (!toast || !toast.parentElement) return;
    toast.classList.add('saindo');
    setTimeout(() => toast.remove(), 250);
}

function solicitarPermissaoNotif() {
    if (!('Notification' in window)) { alert('Seu navegador não suporta notificações nativas.'); return; }
    Notification.requestPermission().then(perm => {
        if (perm === 'granted') new Notification('FamilyFlow ✅', { body: 'Notificações do navegador ativadas!' });
    });
}

function formatarTempoNotif(data) {
    const diff = Math.floor((new Date() - data) / 1000);
    if (diff < 5)   return 'agora mesmo';
    if (diff < 60)  return `há ${diff}s`;
    if (diff < 3600) return `há ${Math.floor(diff/60)}min`;
    return `há ${Math.floor(diff/3600)}h`;
}
