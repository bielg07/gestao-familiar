-- ============================================
-- FAMILYFLOW — Banco de Dados MySQL
-- ============================================
-- Execute: mysql -u root -p < database.sql

CREATE DATABASE IF NOT EXISTS familyflow
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE familyflow;

-- ── USUÁRIOS ──
CREATE TABLE IF NOT EXISTS usuarios (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nome          VARCHAR(100) NOT NULL,
    email         VARCHAR(150) NOT NULL UNIQUE,
    senha_hash    VARCHAR(255) NOT NULL,
    criado_em     DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ── MEMBROS DA FAMÍLIA ──
CREATE TABLE IF NOT EXISTS membros (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    usuario_id  INT UNSIGNED NOT NULL,
    nome        VARCHAR(100) NOT NULL,
    papel       VARCHAR(80)  NOT NULL,
    cor         VARCHAR(7)   NOT NULL DEFAULT '#6b9fff',
    criado_em   DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ── ATIVIDADES ──
CREATE TABLE IF NOT EXISTS atividades (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    usuario_id    INT UNSIGNED NOT NULL,
    titulo        VARCHAR(200) NOT NULL,
    descricao     TEXT,
    categoria     ENUM('escolar','esporte','social') NOT NULL DEFAULT 'escolar',
    status        ENUM('pendente','em andamento','concluida') NOT NULL DEFAULT 'pendente',
    data          DATE NOT NULL,
    hora          TIME NOT NULL,
    criado_em     DATETIME DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ── ATIVIDADE ↔ MEMBROS (N:N) ──
CREATE TABLE IF NOT EXISTS atividade_membros (
    atividade_id  INT UNSIGNED NOT NULL,
    membro_id     INT UNSIGNED NOT NULL,
    PRIMARY KEY (atividade_id, membro_id),
    FOREIGN KEY (atividade_id) REFERENCES atividades(id) ON DELETE CASCADE,
    FOREIGN KEY (membro_id)    REFERENCES membros(id)    ON DELETE CASCADE
) ENGINE=InnoDB;

-- ── SESSÕES (token Bearer) ──
CREATE TABLE IF NOT EXISTS sessoes (
    token       CHAR(64)     PRIMARY KEY,
    usuario_id  INT UNSIGNED NOT NULL,
    expira_em   DATETIME     NOT NULL,
    criado_em   DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ── ÍNDICES ──
CREATE INDEX idx_membros_usuario    ON membros(usuario_id);
CREATE INDEX idx_atividades_usuario ON atividades(usuario_id);
CREATE INDEX idx_atividades_data    ON atividades(data);
CREATE INDEX idx_sessoes_expira     ON sessoes(expira_em);
