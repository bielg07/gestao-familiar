<?php
// ============================================
// index.php — Roteador principal da API
// Funciona SEM mod_rewrite (XAMPP escolar etc)
// Uso: index.php?rota=/auth/login
// ============================================

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

function jsonOk(mixed $data, int $code = 200): never {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function jsonErro(int $code, string $msg): never {
    http_response_code($code);
    echo json_encode(['erro' => $msg], JSON_UNESCAPED_UNICODE);
    exit;
}

$GLOBALS['body'] = json_decode(file_get_contents('php://input'), true) ?? [];

// Pega a rota do parâmetro ?rota=/auth/login
$uri    = $_GET['rota'] ?? '/';
$uri    = trim($uri, '/');
$partes = $uri ? explode('/', $uri) : [];

$GLOBALS['recurso'] = $partes[0] ?? '';
$GLOBALS['id']      = isset($partes[1]) && ctype_digit($partes[1]) ? (int)$partes[1] : null;
$GLOBALS['sub']     = $partes[1] ?? '';
$GLOBALS['method']  = $_SERVER['REQUEST_METHOD'];

switch ($GLOBALS['recurso']) {
    case 'auth':       require __DIR__ . '/api/auth.php';       break;
    case 'membros':    require __DIR__ . '/api/membros.php';    break;
    case 'atividades': require __DIR__ . '/api/atividades.php'; break;
    case 'dashboard':  require __DIR__ . '/api/dashboard.php';  break;
    default:
        jsonErro(404, "Rota '/{$GLOBALS['recurso']}' não encontrada.");
}
