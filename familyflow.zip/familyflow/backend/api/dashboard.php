<?php
// ============================================
// api/dashboard.php — Estatísticas do dashboard
// ============================================
// GET /api/dashboard

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../middleware/auth.php';

if ($GLOBALS['method'] !== 'GET') jsonErro(405, 'Método não permitido.');

$userId = autenticar();
$db     = getDB();

// Contagem por categoria
$cats = $db->prepare('SELECT categoria, COUNT(*) as total FROM atividades WHERE usuario_id = ? GROUP BY categoria');
$cats->execute([$userId]);
$porCategoria = array_column($cats->fetchAll(), 'total', 'categoria');

// Total geral
$totalStmt = $db->prepare('SELECT COUNT(*) FROM atividades WHERE usuario_id = ?');
$totalStmt->execute([$userId]);
$total = (int) $totalStmt->fetchColumn();

// Próximas atividades (5 mais próximas, futuras, não concluídas)
$proxStmt = $db->prepare('
    SELECT a.id, a.titulo, a.categoria, a.status, a.data, a.hora
    FROM atividades a
    WHERE a.usuario_id = ?
      AND a.status != \'concluida\'
      AND CONCAT(a.data, \' \', a.hora) >= NOW()
    ORDER BY a.data ASC, a.hora ASC
    LIMIT 5
');
$proxStmt->execute([$userId]);
$proximas = array_map(fn($r) => [
    'id'        => (string)$r['id'],
    'titulo'    => $r['titulo'],
    'categoria' => $r['categoria'],
    'status'    => $r['status'],
    'data'      => $r['data'],
    'hora'      => substr($r['hora'], 0, 5),
], $proxStmt->fetchAll());

// Membros com contagem de atividades
$membStmt = $db->prepare('
    SELECT m.id, m.nome, m.papel, m.cor,
           COUNT(am.atividade_id) as qtd_atividades
    FROM membros m
    LEFT JOIN atividade_membros am ON am.membro_id = m.id
    WHERE m.usuario_id = ?
    GROUP BY m.id
    ORDER BY m.nome ASC
');
$membStmt->execute([$userId]);
$membrosDash = array_map(fn($r) => [
    'id'             => (string)$r['id'],
    'nome'           => $r['nome'],
    'papel'          => $r['papel'],
    'cor'            => $r['cor'],
    'qtd_atividades' => (int)$r['qtd_atividades'],
], $membStmt->fetchAll());

jsonOk([
    'categorias' => [
        'escolar' => (int)($porCategoria['escolar'] ?? 0),
        'esporte' => (int)($porCategoria['esporte'] ?? 0),
        'social'  => (int)($porCategoria['social']  ?? 0),
    ],
    'total'    => $total,
    'proximas' => $proximas,
    'membros'  => $membrosDash,
]);
