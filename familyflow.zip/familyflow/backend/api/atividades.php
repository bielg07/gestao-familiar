<?php
// ============================================
// api/atividades.php — CRUD de Atividades
// ============================================
// GET    /api/atividades          → lista todas (com filtros via query string)
// POST   /api/atividades          → cria nova
// PUT    /api/atividades/{id}     → atualiza
// DELETE /api/atividades/{id}     → remove

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../middleware/auth.php';

$userId = autenticar();
$method = $GLOBALS['method'];
$id     = $GLOBALS['id'];
$body   = $GLOBALS['body'];
$db     = getDB();

match ($method) {
    'GET'    => listar($db, $userId),
    'POST'   => criar($db, $userId, $body),
    'PUT'    => atualizar($db, $userId, $id, $body),
    'DELETE' => excluir($db, $userId, $id),
    default  => jsonErro(405, 'Método não permitido.')
};

// ─── LISTAR (com filtros opcionais via query string) ──────
// ?nome=&status=&categoria=&membro_id=&data_inicio=
function listar(PDO $db, int $userId): void {
    $where  = ['a.usuario_id = :uid'];
    $params = [':uid' => $userId];

    if (!empty($_GET['status'])) {
        $where[]           = 'a.status = :status';
        $params[':status'] = $_GET['status'];
    }
    if (!empty($_GET['categoria'])) {
        $where[]             = 'a.categoria = :categoria';
        $params[':categoria'] = $_GET['categoria'];
    }
    if (!empty($_GET['nome'])) {
        $where[]         = 'a.titulo LIKE :nome';
        $params[':nome'] = '%' . $_GET['nome'] . '%';
    }
    if (!empty($_GET['data_inicio'])) {
        $where[]               = 'a.data >= :data_inicio';
        $params[':data_inicio'] = $_GET['data_inicio'];
    }
    if (!empty($_GET['membro_id'])) {
        $where[]             = 'EXISTS (SELECT 1 FROM atividade_membros am WHERE am.atividade_id = a.id AND am.membro_id = :membro_id)';
        $params[':membro_id'] = (int)$_GET['membro_id'];
    }

    $sql = '
        SELECT a.id, a.titulo, a.descricao, a.categoria, a.status, a.data, a.hora
        FROM atividades a
        WHERE ' . implode(' AND ', $where) . '
        ORDER BY a.data ASC, a.hora ASC
    ';

    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();

    // Busca membros de cada atividade
    $atividades = [];
    foreach ($rows as $row) {
        $memStmt = $db->prepare('
            SELECT m.id, m.nome, m.cor
            FROM atividade_membros am
            JOIN membros m ON m.id = am.membro_id
            WHERE am.atividade_id = ?
        ');
        $memStmt->execute([$row['id']]);
        $membs = $memStmt->fetchAll();

        $atividades[] = [
            'id'         => (string) $row['id'],
            'titulo'     => $row['titulo'],
            'descricao'  => $row['descricao'] ?? '',
            'categoria'  => $row['categoria'],
            'status'     => $row['status'],
            'data'       => $row['data'],
            'hora'       => substr($row['hora'], 0, 5), // HH:MM
            'membrosIds' => array_map(fn($m) => (string)$m['id'], $membs),
        ];
    }

    jsonOk($atividades);
}

// ─── CRIAR ────────────────────────────────────
function criar(PDO $db, int $userId, array $body): void {
    $dados = validarBody($body);

    $stmt = $db->prepare('
        INSERT INTO atividades (usuario_id, titulo, descricao, categoria, status, data, hora)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ');
    $stmt->execute([
        $userId,
        $dados['titulo'],
        $dados['descricao'],
        $dados['categoria'],
        $dados['status'],
        $dados['data'],
        $dados['hora'],
    ]);
    $novoId = (int) $db->lastInsertId();

    // Vincula membros
    salvarMembros($db, $novoId, $userId, $dados['membrosIds']);

    jsonOk(buscarPorId($db, $novoId, $userId), 201);
}

// ─── ATUALIZAR ────────────────────────────────
function atualizar(PDO $db, int $userId, ?int $id, array $body): void {
    if (!$id) jsonErro(400, 'ID da atividade não informado.');
    checarPropriedade($db, $id, $userId);

    $dados = validarBody($body);

    $db->prepare('
        UPDATE atividades
        SET titulo = ?, descricao = ?, categoria = ?, status = ?, data = ?, hora = ?, atualizado_em = NOW()
        WHERE id = ?
    ')->execute([
        $dados['titulo'], $dados['descricao'], $dados['categoria'],
        $dados['status'],  $dados['data'],      $dados['hora'], $id,
    ]);

    // Recria vínculos de membros
    $db->prepare('DELETE FROM atividade_membros WHERE atividade_id = ?')->execute([$id]);
    salvarMembros($db, $id, $userId, $dados['membrosIds']);

    jsonOk(buscarPorId($db, $id, $userId));
}

// ─── EXCLUIR ──────────────────────────────────
function excluir(PDO $db, int $userId, ?int $id): void {
    if (!$id) jsonErro(400, 'ID da atividade não informado.');
    $atv = checarPropriedade($db, $id, $userId);
    $db->prepare('DELETE FROM atividades WHERE id = ?')->execute([$id]);
    jsonOk(['mensagem' => "Atividade '{$atv['titulo']}' removida."]);
}

// ─── HELPERS ──────────────────────────────────
function validarBody(array $body): array {
    $titulo    = trim($body['titulo']    ?? '');
    $descricao = trim($body['descricao'] ?? '');
    $categoria = $body['categoria'] ?? '';
    $status    = $body['status']    ?? 'pendente';
    $data      = $body['data']      ?? '';
    $hora      = $body['hora']      ?? '';
    $membrosIds = array_filter(
        array_map('intval', (array)($body['membrosIds'] ?? [])),
        fn($v) => $v > 0
    );

    if (!$titulo)    jsonErro(400, 'Título é obrigatório.');
    if (!$data)      jsonErro(400, 'Data é obrigatória.');
    if (!$hora)      jsonErro(400, 'Hora é obrigatória.');
    if (!in_array($categoria, ['escolar','esporte','social'])) jsonErro(400, 'Categoria inválida.');
    if (!in_array($status, ['pendente','em andamento','concluida'])) jsonErro(400, 'Status inválido.');
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $data)) jsonErro(400, 'Formato de data inválido (YYYY-MM-DD).');
    if (!preg_match('/^\d{2}:\d{2}$/', $hora))        jsonErro(400, 'Formato de hora inválido (HH:MM).');

    return compact('titulo','descricao','categoria','status','data','hora','membrosIds');
}

function salvarMembros(PDO $db, int $atividadeId, int $userId, array $membrosIds): void {
    if (empty($membrosIds)) return;

    // Valida que os membros pertencem ao usuário
    $placeholders = implode(',', array_fill(0, count($membrosIds), '?'));
    $check = $db->prepare("SELECT id FROM membros WHERE id IN ($placeholders) AND usuario_id = ?");
    $check->execute([...$membrosIds, $userId]);
    $validos = array_column($check->fetchAll(), 'id');

    $stmt = $db->prepare('INSERT IGNORE INTO atividade_membros (atividade_id, membro_id) VALUES (?, ?)');
    foreach ($validos as $mid) {
        $stmt->execute([$atividadeId, $mid]);
    }
}

function buscarPorId(PDO $db, int $id, int $userId): array {
    $stmt = $db->prepare('SELECT id, titulo, descricao, categoria, status, data, hora FROM atividades WHERE id = ? AND usuario_id = ?');
    $stmt->execute([$id, $userId]);
    $row = $stmt->fetch();
    if (!$row) jsonErro(404, 'Atividade não encontrada.');

    $memStmt = $db->prepare('SELECT membro_id FROM atividade_membros WHERE atividade_id = ?');
    $memStmt->execute([$id]);
    $membrosIds = array_map(fn($r) => (string)$r['membro_id'], $memStmt->fetchAll());

    return [
        'id'         => (string) $row['id'],
        'titulo'     => $row['titulo'],
        'descricao'  => $row['descricao'] ?? '',
        'categoria'  => $row['categoria'],
        'status'     => $row['status'],
        'data'       => $row['data'],
        'hora'       => substr($row['hora'], 0, 5),
        'membrosIds' => $membrosIds,
    ];
}

function checarPropriedade(PDO $db, int $id, int $userId): array {
    $stmt = $db->prepare('SELECT id, titulo FROM atividades WHERE id = ? AND usuario_id = ?');
    $stmt->execute([$id, $userId]);
    $atv = $stmt->fetch();
    if (!$atv) jsonErro(404, 'Atividade não encontrada.');
    return $atv;
}
