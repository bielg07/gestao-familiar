<?php
// ============================================
// api/membros.php — CRUD de Membros
// ============================================
// GET    /api/membros          → lista todos
// POST   /api/membros          → cria novo  { nome, papel, cor }
// PUT    /api/membros/{id}     → atualiza   { nome, papel, cor }
// DELETE /api/membros/{id}     → remove

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../middleware/auth.php';

$userId = autenticar();
$method = $GLOBALS['method'];
$id     = $GLOBALS['id'];
$body   = $GLOBALS['body'];
$db     = getDB();

match ($method) {
    'GET'    => listar($db, $userId),
    'POST'   => criar($db, $userId, $body),
    'PUT'    => atualizar($db, $userId, $id, $body),
    'DELETE' => excluir($db, $userId, $id),
    default  => jsonErro(405, 'Método não permitido.')
};

// ─── LISTAR ───────────────────────────────────
function listar(PDO $db, int $userId): void {
    $stmt = $db->prepare('
        SELECT id, nome, papel, cor
        FROM membros
        WHERE usuario_id = ?
        ORDER BY nome ASC
    ');
    $stmt->execute([$userId]);
    $rows = $stmt->fetchAll();

    // Converte id para string para manter compatibilidade com o frontend
    $membros = array_map(fn($r) => [
        'id'    => (string) $r['id'],
        'nome'  => $r['nome'],
        'papel' => $r['papel'],
        'cor'   => $r['cor'],
    ], $rows);

    jsonOk($membros);
}

// ─── CRIAR ────────────────────────────────────
function criar(PDO $db, int $userId, array $body): void {
    $nome  = trim($body['nome']  ?? '');
    $papel = trim($body['papel'] ?? '');
    $cor   = trim($body['cor']   ?? '#6b9fff');

    if (!$nome || !$papel) jsonErro(400, 'Nome e papel são obrigatórios.');
    if (!preg_match('/^#[0-9a-fA-F]{6}$/', $cor)) $cor = '#6b9fff';

    $stmt = $db->prepare('INSERT INTO membros (usuario_id, nome, papel, cor) VALUES (?, ?, ?, ?)');
    $stmt->execute([$userId, $nome, $papel, $cor]);
    $novoId = (int) $db->lastInsertId();

    jsonOk([
        'id'    => (string) $novoId,
        'nome'  => $nome,
        'papel' => $papel,
        'cor'   => $cor,
    ], 201);
}

// ─── ATUALIZAR ────────────────────────────────
function atualizar(PDO $db, int $userId, ?int $id, array $body): void {
    if (!$id) jsonErro(400, 'ID do membro não informado.');

    // Garante que o membro pertence ao usuário
    $check = $db->prepare('SELECT id FROM membros WHERE id = ? AND usuario_id = ?');
    $check->execute([$id, $userId]);
    if (!$check->fetch()) jsonErro(404, 'Membro não encontrado.');

    $nome  = trim($body['nome']  ?? '');
    $papel = trim($body['papel'] ?? '');
    $cor   = trim($body['cor']   ?? '#6b9fff');

    if (!$nome || !$papel) jsonErro(400, 'Nome e papel são obrigatórios.');
    if (!preg_match('/^#[0-9a-fA-F]{6}$/', $cor)) $cor = '#6b9fff';

    $db->prepare('UPDATE membros SET nome = ?, papel = ?, cor = ? WHERE id = ?')->execute([$nome, $papel, $cor, $id]);

    jsonOk(['id' => (string)$id, 'nome' => $nome, 'papel' => $papel, 'cor' => $cor]);
}

// ─── EXCLUIR ──────────────────────────────────
function excluir(PDO $db, int $userId, ?int $id): void {
    if (!$id) jsonErro(400, 'ID do membro não informado.');

    $check = $db->prepare('SELECT nome FROM membros WHERE id = ? AND usuario_id = ?');
    $check->execute([$id, $userId]);
    $membro = $check->fetch();
    if (!$membro) jsonErro(404, 'Membro não encontrado.');

    $db->prepare('DELETE FROM membros WHERE id = ?')->execute([$id]);
    jsonOk(['mensagem' => "Membro '{$membro['nome']}' removido."]);
}
