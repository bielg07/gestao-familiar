// ============================================
// FAMILYHUB — Script Principal com API MySQL
// ============================================
// Este arquivo é o coração do frontend.
// Ele gerencia toda a interação do usuário com a interface:
// autenticação, CRUD de membros e atividades, calendário,
// dashboard, filtros, modais e sistema de notificações.

// ─── CONFIGURAÇÃO DA API ───────────────────────────────────────────
// URL base do backend PHP. Todas as requisições são feitas para este endereço.
// Em produção, substitua pelo endereço real do servidor.
const API_URL = 'http://localhost/Dev_2o_Ano/familyhub/FamilyHub/backend/index.php';

// ─── ESTADO LOCAL (CACHE) ─────────────────────────────────────────
// Armazena os dados recebidos da API para evitar requisições repetidas.
// Quando o usuário filtra ou renderiza novamente, usa esses arrays locais.
let atividades = []; // Cache de todas as atividades do usuário
let membros    = []; // Cache de todos os membros do usuário
let calendar;        // Instância do FullCalendar (inicializada depois)

// ─── GERENCIAMENTO DO TOKEN (localStorage) ────────────────────────
// O token Bearer é salvo no localStorage do navegador para persistir entre recarregamentos.

// Lê o token salvo no localStorage (retorna null se não existir)
function getToken() {
    return localStorage.getItem('ff_token');
}

// Salva o token no localStorage com a chave 'ff_token'
function setToken(token) {
    localStorage.setItem('ff_token', token);
}

// Lê os dados do usuário logado (objeto JSON salvo como string)
function getUsuario() {
    const raw = localStorage.getItem('ff_usuario');
    // JSON.parse converte a string de volta para objeto JavaScript
    // O operador ternário retorna null se não houver dado salvo
    return raw ? JSON.parse(raw) : null;
}

// Serializa o objeto usuário para string JSON e salva no localStorage
function setUsuario(user) {
    localStorage.setItem('ff_usuario', JSON.stringify(user));
}

// ─── HELPER: api() — Fetch autenticado ────────────────────────────
// Função central que faz TODAS as requisições HTTP ao backend.
// Adiciona automaticamente o token Bearer e trata erros de autenticação.
// Retorna os dados JSON da resposta ou lança um Error.
async function api(path, options = {}) {
    const token = getToken(); // Lê o token do localStorage

    // fetch() faz a requisição HTTP. A URL é montada com a rota como query string.
    const res = await fetch(`${API_URL}?rota=${path}`, {
        ...options, // Espalha as opções recebidas (method, body, etc.)
        headers: {
            'Content-Type': 'application/json', // Informa que o corpo é JSON
            // Se houver token, adiciona o cabeçalho Authorization com Bearer
            // O spread {} mescla os cabeçalhos extras que vieram em options.headers
            ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
            ...(options.headers || {}),
        },
        // Se houver body, serializa para JSON; caso contrário, undefined (sem corpo)
        body: options.body ? JSON.stringify(options.body) : undefined,
    });

    // Se o backend retornar 401 (Unauthorized), o token expirou ou é inválido.
    // Limpa o localStorage e redireciona para a tela de login.
    if (res.status === 401) {
        localStorage.clear();
        window.location.href = 'login.html';
        return; // Encerra a função (o redirect pode demorar um instante)
    }

    const data = await res.json(); // Desserializa a resposta JSON

    // Se a resposta não for OK (status fora de 200-299), lança um erro
    // com a mensagem do campo 'erro' retornado pelo backend
    if (!res.ok) {
        throw new Error(data.erro || 'Erro na requisição.');
    }

    return data; // Retorna os dados para quem chamou api()
}

// ─── VERIFICAÇÃO DE AUTENTICAÇÃO ──────────────────────────────────
// Chamada no início do carregamento da página.
// Redireciona para login se não houver token salvo.
function checarAuth() {
    if (!getToken()) {
        window.location.href = 'login.html';
    }
}

// ─── LOGOUT ───────────────────────────────────────────────────────
// Invalida a sessão no servidor e limpa os dados locais.
async function logout() {
    try {
        // Chama o endpoint de logout no backend para invalidar o token no banco
        await api('/auth/logout', { method: 'POST' });
    } catch (_) {
        // Ignora erros de rede — o logout local acontecerá de qualquer forma
    }
    localStorage.clear();           // Remove token e dados do usuário do navegador
    window.location.href = 'login.html'; // Redireciona para login
}

// ─── FUNÇÕES UTILITÁRIAS ──────────────────────────────────────────

// Retorna a data de hoje no formato AAAA-MM-DD, com offset opcional em dias.
// offset = 0 → hoje; offset = 1 → amanhã; offset = -1 → ontem
function hoje(offset = 0) {
    const d = new Date();
    d.setDate(d.getDate() + offset); // Adiciona/subtrai dias
    return d.toISOString().split('T')[0]; // '2026-02-19T14:30:00.000Z' → '2026-02-19'
}

// Retorna a cor HEX correspondente à categoria para uso no FullCalendar
function getCor(cat) {
    if (cat === 'escolar') return '#4f8ef7'; // Azul
    if (cat === 'esporte') return '#34d399'; // Verde
    return '#f06292';                         // Rosa (social)
}

// Retorna o nome da classe CSS de cor para a bolinha (dot) de categoria
function getCorNome(cat) {
    if (cat === 'escolar') return 'blue';
    if (cat === 'esporte') return 'green';
    return 'pink';
}

// Coloca a primeira letra em maiúsculo: 'escolar' → 'Escolar'
function capitalize(str) {
    if (!str) return '';
    return str.charAt(0).toUpperCase() + str.slice(1);
}

// Converte o valor interno do status para texto legível ao usuário
function statusText(status) {
    const map = {
        'pendente': 'Pendente',
        'em andamento': 'Em Andamento',
        'concluida': 'Concluída',
    };
    return map[status] || capitalize(status || 'pendente');
}

// Gera o HTML do badge de prioridade com ícone colorido
// Retorna uma string HTML com a classe e o ícone de prioridade
function prioridadeBadge(p) {
    if (p === 'urgente')       return '<span class="prio-badge urgente">🔴 Urgente</span>';
    if (p === 'pouco urgente') return '<span class="prio-badge pouco">🟡 Pouco Urgente</span>';
    return '<span class="prio-badge nao">🟢 Não Urgente</span>';
}

// Formata uma data no formato AAAA-MM-DD para exibição amigável em pt-BR
// 'T12:00:00' é adicionado para evitar o problema de fuso horário:
// sem isso, new Date('2026-02-19') seria interpretado como UTC+0 e
// poderia mostrar dia 18 em fusos negativos
function formatarData(dataStr) {
    return new Date(dataStr + 'T12:00:00').toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' });
}

// Exibe ou oculta um spinner de carregamento dentro de um botão.
// Desativa o botão enquanto carrega para evitar cliques duplicados.
function setLoading(elementId, on) {
    const el = document.getElementById(elementId);
    if (!el) return;
    if (on) {
        // Salva o HTML original para restaurar depois
        el.dataset.original = el.innerHTML;
        // Substitui por um ícone de spinner animado via CSS (spin keyframe)
        el.innerHTML = '<i class="ph ph-spinner" style="animation:spin 0.7s linear infinite;display:inline-block"></i>';
        el.disabled = true; // Impede novos cliques
    } else {
        el.innerHTML = el.dataset.original || el.innerHTML; // Restaura conteúdo original
        el.disabled = false;
    }
}

// Exibe um erro como notificação toast (usando o sistema de notificações)
function mostrarErroGlobal(msg) {
    pushNotif({ tipo: 'erro', icone: 'ph-warning', cor: 'urgente', titulo: 'Erro', desc: msg });
}

// ─── INICIALIZAÇÃO DA PÁGINA ─────────────────────────────────────
// DOMContentLoaded: executado quando o HTML foi totalmente carregado,
// mas antes de imagens e CSS externos (mais rápido que window.onload)
document.addEventListener('DOMContentLoaded', async () => {
    checarAuth(); // Redireciona para login se não autenticado

    // Atualiza a data exibida no cabeçalho com formatação em português
    const headerDate = document.getElementById('header-date');
    if (headerDate) {
        headerDate.textContent = new Date().toLocaleDateString('pt-BR', {
            weekday: 'short', day: 'numeric', month: 'short', year: 'numeric'
        });
    }

    // Exibe o nome e a inicial do usuário logado na sidebar
    const usuario = getUsuario();
    if (usuario) {
        const userNameEl = document.querySelector('.user-name');
        if (userNameEl) userNameEl.textContent = usuario.nome;
        const avatarEl = document.querySelector('.avatar-small');
        // toUpperCase() pega a inicial do nome em maiúsculo para o avatar
        if (avatarEl) avatarEl.textContent = usuario.nome[0].toUpperCase();
    }

    // Cria e adiciona o botão de Sair dinamicamente no rodapé da sidebar.
    // Feito via JavaScript para centralizar a lógica de logout aqui.
    const sidebarFooter = document.querySelector('.sidebar-footer');
    if (sidebarFooter) {
        const logoutBtn = document.createElement('button');
        logoutBtn.className = 'menu-item';
        logoutBtn.style.marginTop = '6px';
        logoutBtn.innerHTML = '<span class="menu-icon"><i class="ph ph-sign-out"></i></span><span>Sair</span>';
        // confirm() exibe um diálogo de confirmação nativo do navegador antes de fazer logout
        logoutBtn.onclick = () => { if (confirm('Deseja sair?')) logout(); };
        sidebarFooter.appendChild(logoutBtn);
    }

    // Carrega membros e atividades do banco em paralelo (Promise.all)
    await carregarTudo();

    initCalendar();        // Inicializa o calendário FullCalendar
    initNotificacoes();    // Inicializa o sistema de notificações

    // Adiciona listeners nos filtros: qualquer mudança re-renderiza as atividades
    // 'input' dispara a cada caractere digitado (diferente de 'change' que dispara ao sair do campo)
    ['filter-nome', 'filter-status', 'filter-categoria', 'filter-membro', 'filter-data-inicio'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.addEventListener('input', () => renderizarAtividades());
    });
});

// Carrega membros e atividades do backend e atualiza toda a interface
async function carregarTudo() {
    try {
        // Promise.all executa ambas as requisições SIMULTANEAMENTE (em paralelo)
        // e espera as duas terminarem. Mais rápido que fazer uma de cada vez.
        // Desestruturação: [membros, atividades] = [resultadoMembros, resultadoAtividades]
        [membros, atividades] = await Promise.all([
            api('/membros'),    // GET /membros → retorna array de membros
            api('/atividades'), // GET /atividades → retorna array de atividades
        ]);
    } catch (e) {
        mostrarErroGlobal('Erro ao carregar dados: ' + e.message);
        membros = []; atividades = []; // Garante que os arrays estejam vazios em caso de erro
    }

    renderizarMembros();      // Atualiza a lista de membros na aba Membros
    renderizarAtividades();   // Atualiza a lista de atividades na aba Atividades
    popularFiltroMembros();   // Popula o <select> de filtro com os membros
    atualizarDashboard();     // Atualiza contadores e lista do Dashboard
    atualizarCalendario();    // Atualiza eventos no calendário
    renderizarProximos7();    // Atualiza a lista de eventos dos próximos 7 dias
}

// ─── NAVEGAÇÃO POR ABAS ───────────────────────────────────────────
// Alterna a aba ativa na sidebar e exibe o conteúdo correspondente.
function mudarTab(tabName, btn) {
    // Oculta TODAS as abas adicionando a classe 'hidden'
    document.querySelectorAll('.tab-content').forEach(t => t.classList.add('hidden'));
    // Remove destaque de TODOS os itens do menu
    document.querySelectorAll('.menu-item').forEach(m => m.classList.remove('active'));

    // Exibe a aba clicada removendo 'hidden'
    document.getElementById(`tab-${tabName}`).classList.remove('hidden');
    // Destaca o botão do menu correspondente
    btn.classList.add('active');

    // Mapa de nome interno → título exibido no topo e no breadcrumb
    const titulos = { dashboard: 'Visão Geral', calendario: 'Agenda', membros: 'Gestão Familiar', atividades: 'Atividades' };
    const breadcrumbs = { dashboard: 'Início', calendario: 'Início › Calendário', membros: 'Início › Membros', atividades: 'Início › Atividades' };
    document.getElementById('page-title').innerText = titulos[tabName];
    const bc = document.getElementById('breadcrumb');
    if (bc) bc.innerText = breadcrumbs[tabName];

    // O FullCalendar pode ter problemas de renderização se estiver oculto.
    // updateSize() recalcula as dimensões após ser exibido.
    if (tabName === 'calendario' && calendar) {
        setTimeout(() => { calendar.updateSize(); renderizarProximos7(); }, 200);
    }
}

// ─── CALENDÁRIO (FullCalendar) ─────────────────────────────────────
// Inicializa a instância do FullCalendar com configurações e eventos
function initCalendar() {
    const calendarEl = document.getElementById('calendar');
    calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth', // Visão inicial: grid mensal
        locale: 'pt-br',             // Tradução para português brasileiro
        height: 560,                 // Altura fixa do calendário em pixels
        // Toolbar: botões de navegação à esquerda, título no centro, seletor de view à direita
        headerToolbar: { left: 'prev,next today', center: 'title', right: 'dayGridMonth,listWeek' },
        events: gerarEventos(), // Popula com as atividades já carregadas
        // Ao clicar num evento, abre o modal de edição com os dados daquela atividade
        eventClick: info => abrirModalAtividade(info.event.id),
        // Ao clicar num dia, exibe no painel lateral os eventos daquele dia
        dateClick: info => mostrarEventosDia(info.dateStr),
    });
    calendar.render();          // Renderiza o calendário no DOM
    renderizarProximos7();      // Preenche a lista de próximos 7 dias
}

// Converte o array de atividades para o formato que o FullCalendar espera
function gerarEventos() {
    return atividades.map(a => ({
        id: a.id,                                    // ID do evento (usado em eventClick)
        title: a.titulo,                             // Texto exibido no evento
        start: a.data + 'T' + a.hora,               // Data e hora de início: '2026-02-19T14:30'
        backgroundColor: getCor(a.categoria),        // Cor de fundo do evento por categoria
        borderColor: 'transparent',                  // Sem borda visível
        textColor: '#ffffff',                        // Texto branco para contraste
        extendedProps: { categoria: a.categoria, status: a.status }, // Dados extras acessíveis
    }));
}

// Remove todos os eventos do calendário e adiciona novamente (atualização completa)
function atualizarCalendario() {
    if (calendar) {
        calendar.removeAllEvents();         // Remove eventos antigos
        calendar.addEventSource(gerarEventos()); // Adiciona os novos eventos
    }
}

// Exibe no painel lateral os eventos de um dia específico clicado no calendário
function mostrarEventosDia(dateStr) {
    const titleEl = document.getElementById('day-detail-title');
    const listEl  = document.getElementById('day-events-list');

    // Formata a data: 'T00:00:00' para evitar problemas de fuso horário
    const date    = new Date(dateStr + 'T00:00:00');
    const formatted = date.toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' });
    titleEl.innerHTML = `<i class="ph ph-calendar-check"></i><span>${formatted}</span>`;

    // Filtra atividades que têm a mesma data clicada e ordena por hora
    const eventos = atividades.filter(a => a.data === dateStr).sort((a, b) => a.hora.localeCompare(b.hora));
    if (eventos.length === 0) { listEl.innerHTML = '<p class="empty-day">Nenhum evento neste dia.</p>'; return; }

    // Gera um item HTML para cada evento do dia
    listEl.innerHTML = eventos.map(a => `
        <div class="day-event-item" onclick="abrirModalAtividade('${a.id}')">
            <div class="day-event-title">
                <span class="dot ${getCorNome(a.categoria)}" style="margin-right:6px;display:inline-block"></span>${a.titulo}
            </div>
            <div class="day-event-meta">
                <span>${a.hora}</span><span>·</span>
                <!-- replace(' ','-') converte 'em andamento' → 'em-andamento' para a classe CSS -->
                <span class="status-badge ${(a.status||'pendente').replace(' ','-')}">${statusText(a.status)}</span>
            </div>
        </div>`).join('');
}

// Renderiza a lista de atividades dos próximos 7 dias no painel lateral do calendário
function renderizarProximos7() {
    const lista = document.getElementById('upcoming-7-list');
    if (!lista) return;

    const now = new Date(); // Momento atual
    const futuro = new Date();
    futuro.setDate(futuro.getDate() + 7); // Data daqui a 7 dias

    // Filtra atividades que ocorrem entre agora e 7 dias no futuro
    // e ordena da mais próxima para a mais distante
    const proximos = atividades
        .filter(a => { const d = new Date(a.data + 'T' + a.hora); return d >= now && d <= futuro; })
        .sort((a, b) => (a.data + a.hora).localeCompare(b.data + b.hora));

    if (proximos.length === 0) { lista.innerHTML = '<p class="empty-day">Nenhum evento nos próximos 7 dias.</p>'; return; }

    // Gera o HTML de cada item da lista "próximos 7 dias"
    lista.innerHTML = proximos.map(a => {
        const d = new Date(a.data + 'T00:00:00');
        return `<div class="upcoming-item">
            <div class="upcoming-date">
                <div class="upcoming-day">${d.toLocaleDateString('pt-BR',{day:'2-digit'})}</div>
                <div class="upcoming-month">${d.toLocaleDateString('pt-BR',{month:'short'})}</div>
            </div>
            <div class="upcoming-info">
                <div class="upcoming-title">${a.titulo}</div>
                <div class="upcoming-cat">
                    <span class="dot ${getCorNome(a.categoria)}" style="display:inline-block;margin-right:4px"></span>
                    ${capitalize(a.categoria)} · ${a.hora}
                </div>
            </div>
        </div>`;
    }).join('');
}

// ─── CRUD: ATIVIDADES ─────────────────────────────────────────────

// Abre o modal de criação ou edição de atividade.
// Se idParaEditar for fornecido, preenche o formulário com os dados existentes.
// Se null, limpa o formulário para criação de nova atividade.
function abrirModalAtividade(idParaEditar = null) {
    // Exibe o overlay escuro e o modal de atividade; oculta o modal de membro
    document.getElementById('modal-overlay').classList.remove('hidden');
    document.getElementById('modal-atividade').classList.remove('hidden');
    document.getElementById('modal-membro').classList.add('hidden');

    const form   = document.querySelector('#modal-atividade form');
    const btnDel = document.getElementById('btn-delete-ativ');
    const title  = document.querySelector('#modal-atividade .modal-title');

    // Reconstrói dinamicamente os checkboxes de membros no modal
    const listaMembros = document.getElementById('ativ-membros-list');
    listaMembros.innerHTML = '';
    membros.forEach(m => {
        // Template literal gera o HTML de cada checkbox com estilo personalizado pela cor do membro
        listaMembros.innerHTML += `
            <label class="member-checkbox">
                <input type="checkbox" value="${m.id}" class="ativ-membro-check">
                <span class="member-chip" style="--chip-color:${m.cor}">
                    <!-- chip-avatar: círculo com a inicial do membro na cor do membro -->
                    <span class="chip-avatar" style="background:${m.cor}">${m.nome[0]}</span>
                    ${m.nome}
                </span>
            </label>`;
    });

    if (idParaEditar) {
        // MODO EDIÇÃO: encontra a atividade no cache local pelo ID
        const item = atividades.find(a => a.id == idParaEditar); // == compara int e string
        if (!item) return;
        title.textContent = 'Editar Atividade';

        // Preenche cada campo do formulário com os dados da atividade
        document.getElementById('ativ-id').value        = item.id;
        document.getElementById('ativ-titulo').value    = item.titulo;
        document.getElementById('ativ-descricao').value = item.descricao || '';
        document.getElementById('ativ-categoria').value = item.categoria;
        document.getElementById('ativ-status').value     = item.status || 'pendente';
        document.getElementById('ativ-prioridade').value = item.prioridade || 'nao urgente';
        document.getElementById('ativ-data').value       = item.data;
        document.getElementById('ativ-hora').value      = item.hora;

        // Marca os checkboxes dos membros que participam desta atividade
        (item.membrosIds || []).forEach(mid => {
            const cb = listaMembros.querySelector(`input[value="${mid}"]`);
            if (cb) cb.checked = true; // Marca como selecionado
        });

        btnDel.classList.remove('hidden'); // Exibe botão de deletar (só no modo edição)
    } else {
        // MODO CRIAÇÃO: limpa o formulário
        title.textContent = 'Nova Atividade';
        form.reset();                                         // Reseta todos os campos
        document.getElementById('ativ-id').value = '';       // Limpa ID oculto
        btnDel.classList.add('hidden');                       // Oculta botão de deletar
    }
}

// Salva uma atividade (cria ou atualiza dependendo se há ID no campo oculto)
async function salvarAtividade(e) {
    e.preventDefault(); // Impede o comportamento padrão do formulário (recarregar a página)

    // Lê todos os valores dos campos do formulário
    const id        = document.getElementById('ativ-id').value;
    const titulo    = document.getElementById('ativ-titulo').value;
    const descricao = document.getElementById('ativ-descricao').value;
    const categoria = document.getElementById('ativ-categoria').value;
    const status    = document.getElementById('ativ-status').value;
    const data      = document.getElementById('ativ-data').value;
    const hora       = document.getElementById('ativ-hora').value;
    const prioridade = document.getElementById('ativ-prioridade').value;

    // querySelectorAll('.ativ-membro-check:checked') seleciona apenas os checkboxes marcados
    // [...] converte NodeList para Array (necessário para usar .map())
    // .map(cb => cb.value) extrai o value (ID do membro) de cada checkbox
    const membrosIds = [...document.querySelectorAll('.ativ-membro-check:checked')].map(cb => cb.value);

    const payload = { titulo, descricao, categoria, status, prioridade, data, hora, membrosIds };

    // Exibe spinner no botão de salvar durante a requisição
    const btnSalvar = document.querySelector('#modal-atividade button[type="submit"]');
    setLoading(btnSalvar?.id, true); // ?. = optional chaining: não trava se btnSalvar for null

    try {
        let salva;
        if (id) {
            // ID existe → é uma EDIÇÃO: envia PUT para /atividades/{id}
            salva = await api(`/atividades/${id}`, { method: 'PUT', body: payload });
            // Atualiza o item no cache local pelo índice
            const idx = atividades.findIndex(a => a.id == id);
            if (idx > -1) atividades[idx] = salva;

            // Monta lista de nomes dos membros para a mensagem de notificação
            const membrosNomes = membrosIds.map(mid => membros.find(m => m.id == mid)?.nome).filter(Boolean);
            pushNotif({
                tipo: 'atividade-editada', icone: 'ph-pencil-simple', cor: 'breve',
                titulo: 'Atividade atualizada',
                desc: `"${titulo}" foi editada · ${capitalize(categoria)} · ${formatarData(data)} às ${hora}${membrosNomes.length ? ' · ' + membrosNomes.join(', ') : ''}`,
            });
        } else {
            // Sem ID → é uma CRIAÇÃO: envia POST para /atividades
            salva = await api('/atividades', { method: 'POST', body: payload });
            atividades.push(salva); // Adiciona no cache local

            const membrosNomes = membrosIds.map(mid => membros.find(m => m.id == mid)?.nome).filter(Boolean);
            pushNotif({
                tipo: 'atividade-criada', icone: 'ph-plus-circle', cor: 'lembrete',
                titulo: 'Nova atividade criada',
                desc: `"${titulo}" · ${capitalize(categoria)} · ${formatarData(data)} às ${hora}${membrosNomes.length ? ' · Para: ' + membrosNomes.join(', ') : ''}`,
            });
        }

        fecharModais();
        renderizarAtividades();       // Atualiza lista de atividades
        atualizarDashboard();         // Atualiza contadores do dashboard
        atualizarCalendario();        // Atualiza eventos no calendário
        renderizarProximos7();        // Atualiza próximos 7 dias
        verificarCompromissosProximos(); // Verifica se há notificações de proximidade

    } catch (err) {
        mostrarErroGlobal(err.message); // Exibe o erro retornado pela API como notificação
    } finally {
        // finally: executado SEMPRE, com ou sem erro — restaura o botão
        if (btnSalvar) { btnSalvar.disabled = false; }
    }
}

// Remove uma atividade após confirmação do usuário
async function excluirAtividade(id) {
    // Usa o ID passado como parâmetro, ou lê do campo oculto do formulário
    const idToDelete = id || document.getElementById('ativ-id').value;
    if (!confirm('Tem certeza que deseja excluir esta atividade?')) return; // Cancela se o usuário clicar em "Não"

    const atv = atividades.find(a => a.id == idToDelete); // Salva referência para a notificação
    try {
        await api(`/atividades/${idToDelete}`, { method: 'DELETE' }); // Envia DELETE para o backend
        // Remove do cache local pelo ID (mantém todos exceto o deletado)
        atividades = atividades.filter(a => a.id != idToDelete);

        if (atv) {
            pushNotif({
                tipo: 'atividade-excluida', icone: 'ph-trash', cor: 'urgente',
                titulo: 'Atividade removida',
                desc: `"${atv.titulo}" foi excluída da agenda.`,
            });
        }

        fecharModais();
        renderizarAtividades();
        atualizarDashboard();
        atualizarCalendario();
        renderizarProximos7();
        verificarCompromissosProximos();

    } catch (err) {
        mostrarErroGlobal(err.message);
    }
}

// ─── FILTROS DE ATIVIDADES ────────────────────────────────────────

// Lê os valores atuais de todos os campos de filtro
function getFilters() {
    return {
        nome:       (document.getElementById('filter-nome')?.value || '').toLowerCase().trim(),
        status:     document.getElementById('filter-status')?.value || '',
        categoria:  document.getElementById('filter-categoria')?.value || '',
        membro:     document.getElementById('filter-membro')?.value || '',
        dataInicio: document.getElementById('filter-data-inicio')?.value || '',
    };
}

// Aplica os filtros no cache local de atividades e retorna apenas as que passam em todos os critérios
function filtrarAtividades() {
    const f = getFilters();
    return atividades.filter(a => {
        // Cada condição retorna false (elimina a atividade) se o filtro estiver ativo e não bater
        if (f.nome      && !a.titulo.toLowerCase().includes(f.nome)) return false;
        if (f.status    && a.status    !== f.status)    return false;
        if (f.categoria && a.categoria !== f.categoria) return false;
        // includes() verifica se o ID do membro está na lista de membros da atividade
        if (f.membro    && !(a.membrosIds || []).includes(f.membro)) return false;
        if (f.dataInicio && a.data < f.dataInicio)      return false;
        return true; // Passou em todos os filtros: inclui no resultado
    });
}

// Verifica se pelo menos um filtro está ativo (campo não vazio)
function temFiltroAtivo() {
    const f = getFilters();
    return f.nome || f.status || f.categoria || f.membro || f.dataInicio;
}

// Reseta todos os campos de filtro para vazio e re-renderiza
function limparFiltros() {
    ['filter-nome','filter-status','filter-categoria','filter-membro','filter-data-inicio'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.value = ''; // Limpa o valor do campo
    });
    renderizarAtividades(); // Re-renderiza sem nenhum filtro ativo
}

// Popula o <select> de filtro por membro com os membros carregados
function popularFiltroMembros() {
    const select = document.getElementById('filter-membro');
    if (!select) return;
    const current = select.value; // Salva seleção atual para restaurar depois
    select.innerHTML = '<option value="">Membro: Todos</option>'; // Opção padrão
    membros.forEach(m => { select.innerHTML += `<option value="${m.id}">${m.nome}</option>`; });
    select.value = current; // Restaura a seleção que estava ativa antes da atualização
}

// ─── RENDERIZAÇÃO DA LISTA DE ATIVIDADES ──────────────────────────
// Reconstrói a lista de atividades na aba "Atividades" a partir do cache local
function renderizarAtividades() {
    const container = document.getElementById('lista-atividades-ui');
    container.innerHTML = ''; // Limpa o conteúdo anterior

    const filtradas = filtrarAtividades(); // Aplica os filtros ativos
    // [...filtradas] cria cópia para não mutar o array filtrado
    // sort compara por data+hora concatenados: '2026-02-19' + '14:30' → string comparável
    const sorted    = [...filtradas].sort((a, b) => (a.data + a.hora).localeCompare(b.data + b.hora));

    // Atualiza o contador de atividades exibido na interface
    const countEl = document.getElementById('atividades-count');
    if (countEl) {
        countEl.textContent = temFiltroAtivo()
            ? `${sorted.length} de ${atividades.length} atividade${atividades.length !== 1 ? 's' : ''}` // "3 de 10 atividades"
            : `${atividades.length} atividade${atividades.length !== 1 ? 's' : ''} cadastrada${atividades.length !== 1 ? 's' : ''}`;
    }

    // Exibe "X resultados" quando há filtros ativos
    const filterCount = document.getElementById('filter-count');
    if (filterCount) {
        filterCount.innerHTML = temFiltroAtivo()
            ? `<strong>${sorted.length}</strong> resultado${sorted.length !== 1 ? 's' : ''}`
            : '';
    }

    // Se não houver resultados, exibe mensagem de estado vazio
    if (sorted.length === 0) {
        container.innerHTML = temFiltroAtivo()
            ? `<div class="empty-state"><i class="ph ph-magnifying-glass"></i><p>Nenhuma atividade encontrada</p><small>Tente ajustar os filtros</small></div>`
            : `<div class="empty-state"><i class="ph ph-list-checks"></i><p>Nenhuma atividade cadastrada</p><small>Clique em "Nova Atividade" para começar</small></div>`;
        return;
    }

    // Cria um card HTML para cada atividade filtrada e ordenada
    sorted.forEach(a => {
        const card = document.createElement('div'); // Cria elemento div dinamicamente
        card.className = 'activity-card';

        // Formata a data com fuso correto (T12:00:00 evita problemas de timezone)
        const dataFormatada = new Date(a.data + 'T12:00:00').toLocaleDateString('pt-BR', { day: '2-digit', month: 'short', year: 'numeric' });
        // Converte espaço para hífen para compatibilidade com classes CSS
        const statusClass   = (a.status || 'pendente').replace(' ', '-');

        // Gera o bloco de avatares dos membros vinculados à atividade
        let membrosHtml = '';
        if (a.membrosIds?.length) {
            membrosHtml = '<div class="activity-members">';
            a.membrosIds.forEach(mid => {
                // Busca o membro pelo ID no cache local (comparação com == por segurança)
                const m = membros.find(x => x.id == mid);
                if (m) membrosHtml += `<span class="mini-avatar" style="background:${m.cor}" title="${m.nome}">${m.nome[0]}</span>`;
            });
            membrosHtml += '</div>';
        }

        // Injeta o HTML completo do card com todos os dados da atividade
        card.innerHTML = `
            <div class="activity-card-info">
                <span class="dot ${getCorNome(a.categoria)}"></span>
                <div style="min-width:0">
                    <h4>${a.titulo} <span class="status-badge ${statusClass}">${statusText(a.status)}</span> ${prioridadeBadge(a.prioridade)}</h4>
                    ${a.descricao ? `<p class="activity-desc">${a.descricao}</p>` : ''}
                    <div class="activity-meta">
                        <i class="ph ph-tag"></i> ${capitalize(a.categoria)}
                        &nbsp;·&nbsp;<i class="ph ph-calendar"></i> ${dataFormatada}
                        &nbsp;·&nbsp;<i class="ph ph-clock"></i> ${a.hora}
                    </div>
                    ${membrosHtml}
                </div>
            </div>
            <div class="member-actions">
                <!-- onclick passa o ID diretamente para as funções de editar/excluir -->
                <button class="btn-action" onclick="abrirModalAtividade('${a.id}')" title="Editar"><i class="ph ph-pencil-simple"></i></button>
                <button class="btn-action delete" onclick="excluirAtividade('${a.id}')" title="Excluir"><i class="ph ph-trash"></i></button>
            </div>`;
        container.appendChild(card); // Adiciona o card ao container no DOM
    });
}

// ─── CRUD: MEMBROS ────────────────────────────────────────────────

// Reconstrói a lista de membros na aba "Membros"
function renderizarMembros() {
    const container = document.getElementById('lista-membros-ui');
    container.innerHTML = ''; // Limpa a lista atual

    const countEl = document.getElementById('membros-count');
    if (countEl) countEl.textContent = `${membros.length} membro${membros.length !== 1 ? 's' : ''} cadastrado${membros.length !== 1 ? 's' : ''}`;

    membros.forEach(m => {
        // Conta quantas atividades estão vinculadas a este membro
        // Usa == para comparar string e number (IDs podem ser de tipos diferentes)
        const qtd  = atividades.filter(a => (a.membrosIds || []).includes(m.id) || (a.membrosIds || []).includes(String(m.id))).length;

        const card = document.createElement('div');
        card.className = 'member-card';
        card.innerHTML = `
            <!-- Avatar circular com a cor e a inicial do membro -->
            <div class="member-avatar-large" style="background:${m.cor}">${m.nome[0]}</div>
            <div><h3>${m.nome}</h3><span class="member-role-text">${m.papel}</span></div>
            <span class="member-activity-count">${qtd} atividade${qtd !== 1 ? 's' : ''}</span>
            <div class="member-actions">
                <button class="btn-action" onclick="editarMembro('${m.id}')"><i class="ph ph-pencil-simple"></i></button>
                <button class="btn-action delete" onclick="excluirMembro('${m.id}')"><i class="ph ph-trash"></i></button>
            </div>`;
        container.appendChild(card);
    });
}

// Abre o modal de membro em modo CRIAÇÃO (campos em branco)
function abrirModalMembro() {
    document.getElementById('modal-overlay').classList.remove('hidden');
    document.getElementById('modal-membro').classList.remove('hidden');
    document.getElementById('modal-atividade').classList.add('hidden');
    document.querySelector('#modal-membro .modal-title').textContent = 'Novo Membro';
    // Limpa todos os campos do formulário de membro
    document.getElementById('membro-id').value    = '';
    document.getElementById('membro-nome').value  = '';
    document.getElementById('membro-papel').value = '';
    document.getElementById('membro-cor').value   = '#4f8ef7'; // Cor padrão
}

// Abre o modal de membro em modo EDIÇÃO, preenchendo com os dados existentes
function editarMembro(id) {
    const m = membros.find(x => x.id == id); // Busca o membro no cache local
    if (!m) return;
    abrirModalMembro(); // Abre o modal limpo primeiro
    document.querySelector('#modal-membro .modal-title').textContent = 'Editar Membro';
    // Preenche os campos com os dados do membro encontrado
    document.getElementById('membro-id').value    = m.id;
    document.getElementById('membro-nome').value  = m.nome;
    document.getElementById('membro-papel').value = m.papel;
    document.getElementById('membro-cor').value   = m.cor;
}

// Salva um membro (cria ou atualiza)
async function salvarMembro(e) {
    e.preventDefault(); // Evita recarregar a página

    const id    = document.getElementById('membro-id').value;
    const nome  = document.getElementById('membro-nome').value;
    const papel = document.getElementById('membro-papel').value;
    const cor   = document.getElementById('membro-cor').value;

    try {
        let salvo;
        if (id) {
            // ID existe → EDIÇÃO: envia PUT para /membros/{id}
            salvo = await api(`/membros/${id}`, { method: 'PUT', body: { nome, papel, cor } });
            // Atualiza no cache local pelo índice
            const idx = membros.findIndex(x => x.id == id);
            if (idx > -1) membros[idx] = salvo;
            pushNotif({
                tipo: 'membro-editado', icone: 'ph-pencil-simple', cor: 'breve',
                titulo: 'Membro atualizado',
                desc: `${nome} (${papel}) teve seus dados atualizados.`,
            });
        } else {
            // Sem ID → CRIAÇÃO: envia POST para /membros
            salvo = await api('/membros', { method: 'POST', body: { nome, papel, cor } });
            membros.push(salvo); // Adiciona no cache local
            pushNotif({
                tipo: 'membro-criado', icone: 'ph-user-plus', cor: 'lembrete',
                titulo: 'Novo membro adicionado',
                desc: `${nome} entrou como ${papel} na família. 👋`,
            });
        }

        renderizarMembros();      // Atualiza lista de membros
        popularFiltroMembros();   // Atualiza o select de filtro
        atualizarDashboard();     // Atualiza contadores do dashboard
        fecharModais();

    } catch (err) {
        mostrarErroGlobal(err.message);
    }
}

// Remove um membro após confirmação
async function excluirMembro(id) {
    if (!confirm('Remover este membro da família?')) return;
    const m = membros.find(x => x.id == id); // Guarda referência para a notificação
    try {
        await api(`/membros/${id}`, { method: 'DELETE' });
        membros = membros.filter(x => x.id != id); // Remove do cache local
        if (m) {
            pushNotif({
                tipo: 'membro-excluido', icone: 'ph-user-minus', cor: 'urgente',
                titulo: 'Membro removido',
                desc: `${m.nome} (${m.papel}) foi removido da família.`,
            });
        }
        renderizarMembros();
        popularFiltroMembros();
        atualizarDashboard();
    } catch (err) {
        mostrarErroGlobal(err.message);
    }
}

// ─── DASHBOARD ────────────────────────────────────────────────────
// Recalcula e atualiza todos os elementos visuais do Dashboard
// a partir do cache local (sem fazer nova requisição ao backend)
function atualizarDashboard() {
    // Conta atividades por categoria filtrando o array local
    const escolar = atividades.filter(a => a.categoria === 'escolar').length;
    const esporte = atividades.filter(a => a.categoria === 'esporte').length;
    const social  = atividades.filter(a => a.categoria === 'social').length;
    const total   = atividades.length;

    // Atualiza os números nos cards de estatísticas
    document.getElementById('dash-escolar').innerText = escolar;
    document.getElementById('dash-esporte').innerText = esporte;
    document.getElementById('dash-social').innerText  = social;
    document.getElementById('dash-total').innerText   = total;

    // Atualiza as barras de progresso proporcionais (largura em %)
    if (total > 0) {
        // Cada barra ocupa X% da largura total proporcional à sua categoria
        document.getElementById('bar-escolar').style.width = (escolar / total * 100) + '%';
        document.getElementById('bar-social').style.width  = (social  / total * 100) + '%';
        document.getElementById('bar-esporte').style.width = (esporte / total * 100) + '%';
    }

    // Filtra as próximas atividades: a partir de hoje e não concluídas
    const lista = document.getElementById('lista-recentes');
    const proximas = [...atividades]
        .filter(a => a.data >= hoje(0) && a.status !== 'concluida') // Só futuras não concluídas
        .sort((a, b) => (a.data + a.hora).localeCompare(b.data + b.hora)) // Da mais próxima para a mais distante
        .slice(0, 5); // Limita a 5 itens

    lista.innerHTML = '';
    if (proximas.length === 0) {
        lista.innerHTML = '<li style="color:var(--text-3);font-size:0.82rem;text-align:center;padding:20px 0;">Nenhuma atividade futura.</li>';
    } else {
        proximas.forEach(a => {
            const df = new Date(a.data + 'T12:00:00').toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' });
            lista.innerHTML += `
                <li>
                    <div class="item-left">
                        <span class="dot ${getCorNome(a.categoria)}"></span>
                        <span class="item-title">${a.titulo}</span>
                    </div>
                    <span class="item-date">${df} · ${a.hora}</span>
                </li>`;
        });
    }

    // Renderiza a lista de membros no dashboard com contagem de atividades de cada um
    const dashMembros = document.getElementById('dash-membros-list');
    if (dashMembros) {
        dashMembros.innerHTML = '';
        membros.forEach(m => {
            // .map(String) converte todos os IDs para string antes de comparar
            const qtd = atividades.filter(a => (a.membrosIds || []).map(String).includes(String(m.id))).length;
            dashMembros.innerHTML += `
                <div class="dash-member-row">
                    <div class="mini-avatar" style="background:${m.cor}">${m.nome[0]}</div>
                    <div>
                        <div class="member-name">${m.nome}</div>
                        <div class="member-role">${m.papel}</div>
                    </div>
                    <span class="member-count">${qtd} ativ.</span>
                </div>`;
        });
    }
}

// ─── MODAIS ───────────────────────────────────────────────────────

// Fecha todos os modais adicionando a classe 'hidden'
function fecharModais() {
    document.getElementById('modal-overlay').classList.add('hidden');
    document.getElementById('modal-atividade').classList.add('hidden');
    document.getElementById('modal-membro').classList.add('hidden');
}

// Fecha o modal se o usuário clicar no overlay escuro (fora do modal)
function overlayClick(e) {
    // e.target é o elemento clicado; verifica se é o overlay e não um filho dele
    if (e.target === document.getElementById('modal-overlay')) fecharModais();
}

// Fecha o modal ao pressionar a tecla Escape no teclado (UX padrão)
document.addEventListener('keydown', e => { if (e.key === 'Escape') fecharModais(); });

// ============================================
// SISTEMA DE NOTIFICAÇÕES
// ============================================
// Gerencia três tipos de notificação:
// 1. Notificações de ação (criação, edição, exclusão de membros e atividades)
// 2. Alertas de compromissos próximos (30min, 1h, 1 dia, 3 dias)
// 3. Notificações nativas do navegador (quando permitidas)

let notificacoes = [];                     // Array de todas as notificações geradas na sessão
let notifPanelAberto = false;              // Estado de visibilidade do painel de notificações
let toastContainer = null;                 // Referência ao container de toasts no DOM
let compromissosJaNotificados = new Set(); // Set evita notificar o mesmo compromisso duas vezes

// Inicializa o sistema de notificações: cria o container de toasts e configura listeners
function initNotificacoes() {
    // Evita criar container duplicado se initNotificacoes() for chamado mais de uma vez
    if (document.getElementById('notif-toast-container')) return;

    toastContainer = document.createElement('div');
    toastContainer.className = 'notif-toast-container';
    toastContainer.id = 'notif-toast-container';
    document.body.appendChild(toastContainer); // Adiciona ao final do <body>

    // Fecha o painel de notificações ao clicar FORA dele
    document.addEventListener('click', (e) => {
        const wrapper = document.getElementById('notif-wrapper');
        // contains() verifica se o elemento clicado (e.target) está dentro do wrapper
        if (wrapper && !wrapper.contains(e.target) && notifPanelAberto) fecharNotifPanel();
    });

    verificarCompromissosProximos(); // Verifica imediatamente ao inicializar
    setInterval(verificarCompromissosProximos, 60000); // Verifica novamente a cada 60 segundos
    renderizarNotificacoes(); // Renderiza o painel (provavelmente vazio no início)
}

// Cria e adiciona uma nova notificação ao sistema
// tipo: identificador interno; icone: classe do ícone Phosphor; cor: classe CSS de cor
// titulo: título em negrito; desc: texto descritivo
function pushNotif({ tipo, icone, cor, titulo, desc }) {
    const notif = {
        // ID único: timestamp + string aleatória (evita colisões se duas notificações forem criadas no mesmo ms)
        id: 'n' + Date.now() + Math.random().toString(36).slice(2),
        tipo, icone, cor, titulo, desc,
        criadaEm: new Date(), // Momento de criação para calcular "há X minutos"
        lida: false,          // Notificação começa como não lida
        atividadeId: null,    // Pode ser preenchido para vincular a uma atividade específica
    };
    notificacoes.unshift(notif); // unshift: adiciona no INÍCIO do array (mais recente primeiro)
    mostrarToast(notif);         // Exibe o toast flutuante na tela
    renderizarNotificacoes();    // Atualiza o painel de notificações
}

// Verifica se há atividades próximas que precisam de alerta
function verificarCompromissosProximos() {
    const agora  = new Date();

    // Define os intervalos de alerta com suas configurações visuais
    const alertas = [
        { minutos: 30,   label: 'em 30 minutos', cor: 'urgente', icone: 'ph-warning-circle' },
        { minutos: 60,   label: 'em 1 hora',      cor: 'hoje',   icone: 'ph-clock' },
        { minutos: 1440, label: 'amanhã',          cor: 'breve',  icone: 'ph-calendar-check' },
        { minutos: 4320, label: 'em 3 dias',       cor: 'lembrete',icone: 'ph-bell' },
    ];

    // Lê as configurações de alerta dos checkboxes na interface
    // ?? true/false: valor padrão se o elemento não existir
    const cfg = {
        30:   document.getElementById('alerta-30min')?.checked ?? true,
        60:   document.getElementById('alerta-1h')?.checked   ?? true,
        1440: document.getElementById('alerta-1d')?.checked   ?? true,
        4320: document.getElementById('alerta-3d')?.checked   ?? false,
    };

    atividades.forEach(a => {
        if (a.status === 'concluida') return; // Ignora atividades já concluídas

        const dataAtiv = new Date(a.data + 'T' + a.hora); // Data/hora da atividade
        const diffMin  = (dataAtiv - agora) / 60000; // Diferença em minutos (positivo = futuro)

        // Ignora se já passou (diffMin < 0) ou se está além de 3 dias (diffMin > 4320)
        if (diffMin < 0 || diffMin > 4320) return;

        alertas.forEach(al => {
            // Não alerta se: esta configuração está desativada OU a atividade está além do intervalo
            if (!cfg[al.minutos] || diffMin > al.minutos) return;

            // Chave única para este par atividade+intervalo
            // Evita que a mesma notificação apareça múltiplas vezes ao longo da sessão
            const chave = `${a.id}_${al.minutos}`;
            if (compromissosJaNotificados.has(chave)) return; // Já notificado: pula
            compromissosJaNotificados.add(chave); // Marca como notificado

            // Monta lista de nomes dos membros para enriquecer a notificação
            const membrosNomes = (a.membrosIds || [])
                .map(mid => membros.find(m => m.id == mid)?.nome).filter(Boolean).join(', ');

            const notif = {
                id: 'n' + Date.now() + Math.random().toString(36).slice(2),
                tipo: 'compromisso', icone: al.icone, cor: al.cor,
                titulo: `⏰ ${a.titulo}`,
                desc: `${capitalize(a.categoria)} · ${formatarData(a.data)} às ${a.hora} — ${al.label}${membrosNomes ? ' · ' + membrosNomes : ''}`,
                criadaEm: new Date(), lida: false,
                atividadeId: a.id, // Vincula a notificação à atividade para abrir o modal ao clicar
            };
            notificacoes.unshift(notif);

            // Exibe toast apenas para alertas muito próximos (30 min ou 1 hora)
            if (al.minutos <= 60) mostrarToast(notif);

            // Dispara notificação nativa do navegador se o usuário deu permissão
            // new Notification() cria uma notificação do sistema operacional
            if (Notification.permission === 'granted') {
                new Notification(`⏰ ${a.titulo}`, { body: notif.desc });
            }
        });
    });
    renderizarNotificacoes();
}

// Renderiza o painel de notificações com todas as notificações acumuladas
function renderizarNotificacoes() {
    const lista  = document.getElementById('notif-list');
    const badge  = document.getElementById('notif-badge');
    const btn    = document.getElementById('notif-btn');
    if (!lista) return;

    // Conta quantas notificações ainda não foram lidas
    const naoLidas = notificacoes.filter(n => !n.lida).length;
    if (naoLidas > 0) {
        badge.textContent = naoLidas > 9 ? '9+' : naoLidas; // Limita a "9+" se for muitas
        badge.classList.remove('hidden'); // Exibe o badge com o número
        btn.classList.add('has-unread');  // Destaca o botão de notificações
    } else {
        badge.classList.add('hidden');     // Oculta o badge se não houver não lidas
        btn.classList.remove('has-unread');
    }

    // Estado vazio: nenhuma notificação ainda
    if (notificacoes.length === 0) {
        lista.innerHTML = `<div class="notif-empty"><i class="ph ph-bell-slash"></i>Nenhuma notificação ainda.</div>`;
        return;
    }

    // Gera o HTML de cada item de notificação
    lista.innerHTML = notificacoes.map(n => `
        <div class="notif-item ${n.cor} ${n.lida ? '' : 'unread'}" onclick="clicarNotif('${n.id}')">
            <div class="notif-icon-wrap"><i class="ph ${n.icone}"></i></div>
            <div class="notif-content">
                <div class="notif-title">${n.titulo}</div>
                <div class="notif-desc">${n.desc}</div>
                <div class="notif-time"><i class="ph ph-clock"></i> ${formatarTempoNotif(n.criadaEm)}</div>
            </div>
            <!-- Ponto azul de "não lida" — exibido apenas se lida === false -->
            ${!n.lida ? '<div class="notif-unread-dot"></div>' : ''}
        </div>`).join('');
}

// Ação ao clicar em uma notificação: marca como lida e opcionalmente abre a atividade
function clicarNotif(id) {
    const notif = notificacoes.find(n => n.id === id);
    if (!notif) return;
    notif.lida = true;           // Marca como lida
    renderizarNotificacoes();    // Atualiza o painel (remove o ponto de não lida)
    fecharNotifPanel();          // Fecha o painel
    // Se a notificação estiver vinculada a uma atividade, abre o modal de edição dela
    if (notif.atividadeId) abrirModalAtividade(notif.atividadeId);
}

// Marca TODAS as notificações como lidas de uma vez
function marcarTodasLidas()  { notificacoes.forEach(n => n.lida = true); renderizarNotificacoes(); }

// Remove todas as notificações da lista
function limparTodasNotif()  { notificacoes = []; renderizarNotificacoes(); }

// Alterna a visibilidade do painel de notificações
function toggleNotifPanel()  { notifPanelAberto ? fecharNotifPanel() : abrirNotifPanel(); }

function abrirNotifPanel() {
    document.getElementById('notif-panel').classList.remove('hidden');
    notifPanelAberto = true;
    renderizarNotificacoes(); // Garante que o painel está atualizado ao abrir
}

function fecharNotifPanel() {
    document.getElementById('notif-panel')?.classList.add('hidden');
    document.getElementById('notif-config')?.classList.add('hidden'); // Fecha config se estiver aberta
    notifPanelAberto = false;
}

// Exibe ou oculta o painel de configurações de alertas
function toggleNotifConfig() { document.getElementById('notif-config').classList.toggle('hidden'); }

// Exibe um toast (mensagem flutuante) na tela por 5 segundos com animação de progresso
function mostrarToast(notif) {
    if (!toastContainer) return;
    const duracao = 5000; // Duração em milissegundos

    const toast = document.createElement('div');
    toast.className = 'notif-toast';
    toast.innerHTML = `
        <div class="toast-icon ${notif.cor}"><i class="ph ${notif.icone}"></i></div>
        <div class="toast-body">
            <div class="toast-title">${notif.titulo}</div>
            <div class="toast-desc">${notif.desc}</div>
        </div>
        <button class="toast-close" onclick="fecharToast(this.closest('.notif-toast'))"><i class="ph ph-x"></i></button>
        <!-- Barra de progresso que encolhe de 100% para 0% em 5 segundos -->
        <div class="toast-progress ${notif.cor}" style="width:100%"></div>`;
    toastContainer.appendChild(toast);

    const bar = toast.querySelector('.toast-progress');
    // requestAnimationFrame garante que a barra começa com 100% antes de iniciar a transição CSS
    // (sem isso, a transição poderia não ser percebida pelo navegador)
    requestAnimationFrame(() => { bar.style.transition = `width ${duracao}ms linear`; bar.style.width = '0%'; });

    // Remove o toast automaticamente após o tempo de duração
    setTimeout(() => fecharToast(toast), duracao);
}

// Remove um toast com animação de saída
function fecharToast(toast) {
    if (!toast || !toast.parentElement) return; // Segurança: evita erro se já foi removido
    toast.classList.add('saindo'); // Adiciona classe CSS que dispara animação de fade-out
    setTimeout(() => toast.remove(), 250); // Remove do DOM após a animação terminar (250ms)
}

// Solicita permissão ao usuário para enviar notificações nativas do sistema operacional
function solicitarPermissaoNotif() {
    if (!('Notification' in window)) { alert('Seu navegador não suporta notificações nativas.'); return; }
    // requestPermission() exibe o diálogo do navegador pedindo permissão
    Notification.requestPermission().then(perm => {
        // Se concedida, dispara uma notificação de confirmação imediatamente
        if (perm === 'granted') new Notification('FamilyHub ✅', { body: 'Notificações do navegador ativadas!' });
    });
}

// Formata o tempo decorrido desde a criação de uma notificação
// Retorna strings como "agora mesmo", "há 30s", "há 5min", "há 2h"
function formatarTempoNotif(data) {
    const diff = Math.floor((new Date() - data) / 1000); // Diferença em segundos
    if (diff < 5)    return 'agora mesmo';
    if (diff < 60)   return `há ${diff}s`;          // Até 59 segundos
    if (diff < 3600) return `há ${Math.floor(diff/60)}min`; // Até 59 minutos
    return `há ${Math.floor(diff/3600)}h`;           // 1 hora ou mais
}
