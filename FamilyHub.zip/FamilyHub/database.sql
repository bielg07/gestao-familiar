-- ============================================
-- FAMILYFLOW — Banco de Dados MySQL
-- ============================================
-- Para executar: abra o terminal e rode:
-- mysql -u root -p < database.sql

-- Cria o banco de dados "familyflow" com suporte completo a
-- Unicode (utf8mb4), incluindo emojis e caracteres especiais.
-- O IF NOT EXISTS evita erro caso o banco já exista.
CREATE DATABASE IF NOT EXISTS familyflow
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

-- Seleciona o banco criado acima para usar nos comandos a seguir
USE familyflow;

-- ── TABELA: usuarios ──────────────────────────────────────────────
-- Armazena as contas de acesso ao sistema.
-- Cada usuário tem seu próprio conjunto isolado de membros e atividades.
CREATE TABLE IF NOT EXISTS usuarios (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, -- Identificador único, auto incrementado, nunca negativo
    nome          VARCHAR(100) NOT NULL,                   -- Nome completo do usuário, obrigatório, até 100 caracteres
    email         VARCHAR(150) NOT NULL UNIQUE,            -- E-mail único no sistema (não pode repetir), usado para login
    senha_hash    VARCHAR(255) NOT NULL,                   -- Senha armazenada como hash bcrypt (NUNCA em texto puro)
    criado_em     DATETIME DEFAULT CURRENT_TIMESTAMP       -- Data/hora de cadastro, preenchida automaticamente pelo banco
) ENGINE=InnoDB; -- InnoDB suporta transações e chaves estrangeiras (necessário para integridade dos dados)

-- ── TABELA: membros ───────────────────────────────────────────────
-- Representa cada pessoa da família (pai, mãe, filho, etc.)
-- associada a um usuário específico do sistema.
CREATE TABLE IF NOT EXISTS membros (
    id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, -- ID único do membro
    usuario_id  INT UNSIGNED NOT NULL,                   -- Liga este membro ao usuário dono dele
    nome        VARCHAR(100) NOT NULL,                   -- Nome do membro da família, obrigatório
    papel       VARCHAR(80)  NOT NULL,                   -- Papel/função na família (ex: "Pai", "Filha", "Mãe")
    cor         VARCHAR(7)   NOT NULL DEFAULT '#6b9fff', -- Cor HEX do avatar (ex: #ff5733). Padrão: azul suave
    criado_em   DATETIME DEFAULT CURRENT_TIMESTAMP,      -- Data/hora de criação, automática
    -- Chave estrangeira: se o usuário for deletado, todos os seus membros são deletados em cascata
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ── TABELA: atividades ────────────────────────────────────────────
-- Agenda de atividades da família: aulas, treinos, compromissos sociais.
-- Cada atividade pertence a um usuário e pode ser atribuída a múltiplos membros.
CREATE TABLE IF NOT EXISTS atividades (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,                          -- ID único da atividade
    usuario_id    INT UNSIGNED NOT NULL,                                            -- Usuário dono da atividade
    titulo        VARCHAR(200) NOT NULL,                                            -- Título/nome da atividade, obrigatório
    descricao     TEXT,                                                             -- Descrição livre, opcional (pode ser NULL)
    categoria     ENUM('escolar','esporte','social') NOT NULL DEFAULT 'escolar',    -- Tipo da atividade: apenas esses 3 valores são aceitos
    status        ENUM('pendente','em andamento','concluida') NOT NULL DEFAULT 'pendente', -- Estado atual da atividade
    data          DATE NOT NULL,                                                    -- Data da atividade no formato AAAA-MM-DD
    hora          TIME NOT NULL,                                                    -- Horário da atividade no formato HH:MM:SS
    criado_em     DATETIME DEFAULT CURRENT_TIMESTAMP,                              -- Data/hora de criação, automática
    atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,  -- Atualizada automaticamente a cada UPDATE no registro
    -- Chave estrangeira: se o usuário for deletado, todas as atividades são deletadas
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ── TABELA: atividade_membros ─────────────────────────────────────
-- Tabela de relacionamento N:N (muitos para muitos) entre atividades e membros.
-- Uma atividade pode ter vários membros, e um membro pode ter várias atividades.
-- Ex: "Treino de futebol" → Pedro e João ao mesmo tempo.
CREATE TABLE IF NOT EXISTS atividade_membros (
    atividade_id  INT UNSIGNED NOT NULL,                                           -- ID da atividade
    membro_id     INT UNSIGNED NOT NULL,                                           -- ID do membro
    PRIMARY KEY (atividade_id, membro_id),                                         -- A combinação dos dois é única: evita duplicatas
    -- Se a atividade for deletada, remove os vínculos automaticamente
    FOREIGN KEY (atividade_id) REFERENCES atividades(id) ON DELETE CASCADE,
    -- Se o membro for deletado, remove os vínculos automaticamente
    FOREIGN KEY (membro_id)    REFERENCES membros(id)    ON DELETE CASCADE
) ENGINE=InnoDB;

-- ── TABELA: sessoes ───────────────────────────────────────────────
-- Armazena os tokens de autenticação tipo Bearer.
-- Quando o usuário faz login, um token é gerado e salvo aqui.
-- Cada requisição autenticada usa esse token para identificar o usuário.
CREATE TABLE IF NOT EXISTS sessoes (
    token       CHAR(64)     PRIMARY KEY,                  -- Token hexadecimal de 64 caracteres (32 bytes aleatórios → hex), é a chave primária
    usuario_id  INT UNSIGNED NOT NULL,                      -- Usuário dono desta sessão
    expira_em   DATETIME     NOT NULL,                      -- Data/hora em que o token expira (7 dias após o login)
    criado_em   DATETIME DEFAULT CURRENT_TIMESTAMP,         -- Data/hora de criação do token
    -- Se o usuário for deletado, as sessões são deletadas automaticamente
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ── ÍNDICES DE PERFORMANCE ────────────────────────────────────────
-- Índices aceleram as buscas no banco sem alterar os dados.
-- O MySQL usará esses índices ao filtrar por essas colunas.

-- Acelera buscas de membros por usuário (ex: "quais membros são do usuário 5?")
CREATE INDEX idx_membros_usuario    ON membros(usuario_id);

-- Acelera buscas de atividades por usuário
CREATE INDEX idx_atividades_usuario ON atividades(usuario_id);

-- Acelera buscas de atividades por data (ex: filtrar por intervalo de datas)
CREATE INDEX idx_atividades_data    ON atividades(data);

-- Acelera a limpeza automática de sessões expiradas
CREATE INDEX idx_sessoes_expira     ON sessoes(expira_em);
