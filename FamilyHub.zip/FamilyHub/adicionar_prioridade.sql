-- ============================================
-- FAMILYFLOW — Migração: adicionar Prioridade
-- ============================================
-- Este arquivo é uma MIGRAÇÃO de banco de dados:
-- ele modifica a estrutura de uma tabela já existente
-- SEM apagar os dados que já estão nela.
--
-- Contexto: após o sistema já estar em uso, surgiu a necessidade
-- de adicionar um nível de prioridade às atividades.
-- Execute este arquivo no phpMyAdmin > aba SQL (só precisa rodar UMA VEZ)

-- Seleciona o banco de dados correto antes de alterar qualquer tabela
USE familyflow;

-- Adiciona a coluna "prioridade" na tabela "atividades"
-- ENUM: aceita SOMENTE um desses três valores — 'urgente', 'pouco urgente' ou 'nao urgente'
-- NOT NULL: o campo é obrigatório (não pode ficar vazio)
-- DEFAULT 'nao urgente': se nenhum valor for informado, o banco assume 'nao urgente' automaticamente
-- AFTER status: posiciona a nova coluna logo após a coluna "status" na estrutura da tabela
ALTER TABLE atividades
    ADD COLUMN prioridade ENUM('urgente', 'pouco urgente', 'nao urgente')
    NOT NULL DEFAULT 'nao urgente'
    AFTER status;
