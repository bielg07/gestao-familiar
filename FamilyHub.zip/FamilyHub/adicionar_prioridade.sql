-- ============================================
-- FAMILYFLOW — Migração: adicionar Prioridade
-- ============================================
-- Execute este arquivo no phpMyAdmin > SQL
-- (só precisa rodar UMA VEZ)

USE familyflow;

ALTER TABLE atividades
    ADD COLUMN prioridade ENUM('urgente', 'pouco urgente', 'nao urgente')
    NOT NULL DEFAULT 'nao urgente'
    AFTER status;
