# FamilyFlow — Backend PHP + MySQL

## Estrutura do Projeto

```
familyflow/
├── backend/                  ← API PHP (copie para seu servidor)
│   ├── index.php             ← Roteador principal
│   ├── .htaccess             ← Reescrita de rotas (Apache)
│   ├── config/
│   │   └── db.php            ← Credenciais do banco de dados
│   ├── middleware/
│   │   └── auth.php          ← Validação de token
│   └── api/
│       ├── auth.php          ← Login, Cadastro, Logout
│       ├── membros.php       ← CRUD de membros
│       ├── atividades.php    ← CRUD de atividades
│       └── dashboard.php     ← Estatísticas
│
├── frontend/                 ← Arquivos do frontend
│   ├── index.html            ← App principal
│   ├── login.html            ← Tela de login/cadastro
│   ├── landing.html          ← Página inicial
│   ├── script.js             ← JavaScript com chamadas à API
│   └── style.css             ← Estilos
│
└── database.sql              ← Script de criação do banco
```

---

## Passo a Passo de Instalação

### 1. Requisitos

- PHP 8.1 ou superior (com extensões: pdo, pdo_mysql)
- MySQL 5.7 ou superior (ou MariaDB 10.3+)
- Apache com mod_rewrite ativado (ou Nginx com configuração equivalente)
- XAMPP, WAMP, Laragon, ou servidor Linux com Apache/Nginx

---

### 2. Criar o banco de dados

Abra o terminal (ou o phpMyAdmin) e execute:

```bash
mysql -u root -p < database.sql
```

Ou cole o conteúdo do arquivo `database.sql` diretamente no phpMyAdmin > SQL.

---

### 3. Configurar as credenciais do banco

Edite o arquivo `backend/config/db.php`:

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'familyflow');
define('DB_USER', 'root');       // ← seu usuário MySQL
define('DB_PASS', '');           // ← sua senha MySQL
define('DB_PORT', 3306);
```

---

### 4. Configurar o servidor

#### XAMPP / WAMP (Windows local)

1. Copie a pasta `familyflow/` inteira para dentro de `htdocs/` (XAMPP) ou `www/` (WAMP)
2. Acesse: `http://localhost/familyflow/backend/`
3. Certifique-se de que o `mod_rewrite` está ativado no Apache

Para ativar o mod_rewrite no XAMPP:
- Abra `httpd.conf` e descomente: `LoadModule rewrite_module modules/mod_rewrite.so`
- Mude `AllowOverride None` para `AllowOverride All` na seção do htdocs

#### Laragon (recomendado para Windows)

1. Copie `familyflow/` para `C:\laragon\www\`
2. O Laragon já ativa `mod_rewrite` por padrão
3. Acesse: `http://localhost/familyflow/backend/`

#### Linux (Apache)

```bash
# Copie o projeto
sudo cp -r familyflow/ /var/www/html/

# Ative o mod_rewrite
sudo a2enmod rewrite
sudo systemctl restart apache2
```

No arquivo `/etc/apache2/sites-available/000-default.conf`, confirme:
```
<Directory /var/www/html/>
    AllowOverride All
</Directory>
```

---

### 5. Configurar o Frontend

Edite o arquivo `frontend/script.js` (primeira linha configurável):

```js
const API_URL = 'http://localhost/familyflow/backend';
```

Troque pelo endereço real onde seu backend está rodando. Exemplos:
- Local: `http://localhost/familyflow/backend`
- Servidor: `https://seusite.com/api`

Faça o mesmo no `frontend/login.html` (busque por `API_URL`).

---

### 6. Testar a API

Abra o navegador ou use o Postman:

```
GET  http://localhost/familyflow/backend/auth/me
```

Deve retornar `401 - Token não fornecido.` — sinal que a API está funcionando.

#### Criar primeira conta

```bash
curl -X POST http://localhost/familyflow/backend/auth/cadastro \
  -H "Content-Type: application/json" \
  -d '{"nome":"Seu Nome","email":"email@exemplo.com","senha":"123456"}'
```

---

## Rotas da API

### Autenticação
| Método | Rota               | Descrição             |
|--------|--------------------|-----------------------|
| POST   | /auth/cadastro     | Criar conta           |
| POST   | /auth/login        | Fazer login           |
| POST   | /auth/logout       | Encerrar sessão       |
| GET    | /auth/me           | Dados do usuário      |

### Membros *(requer token)*
| Método | Rota               | Descrição             |
|--------|--------------------|-----------------------|
| GET    | /membros           | Listar membros        |
| POST   | /membros           | Criar membro          |
| PUT    | /membros/{id}      | Atualizar membro      |
| DELETE | /membros/{id}      | Remover membro        |

### Atividades *(requer token)*
| Método | Rota               | Descrição                        |
|--------|--------------------|---------------------------------|
| GET    | /atividades        | Listar (aceita filtros via URL)  |
| POST   | /atividades        | Criar atividade                  |
| PUT    | /atividades/{id}   | Atualizar atividade              |
| DELETE | /atividades/{id}   | Remover atividade                |

**Filtros disponíveis no GET /atividades:**
```
?nome=futebol&status=pendente&categoria=esporte&membro_id=1&data_inicio=2025-01-01
```

### Dashboard *(requer token)*
| Método | Rota               | Descrição             |
|--------|--------------------|-----------------------|
| GET    | /dashboard         | Estatísticas gerais   |

---

## Autenticação

Após login, todas as requisições precisam do header:

```
Authorization: Bearer SEU_TOKEN_AQUI
```

O token é válido por **7 dias**. Após expirar, o sistema redireciona automaticamente para o login.

---

## Problemas comuns

**"Falha na conexão com o banco"**
→ Verifique as credenciais em `config/db.php`

**404 em todas as rotas**
→ O `mod_rewrite` não está ativado. Verifique o `.htaccess` e `AllowOverride All`

**CORS bloqueado no navegador**
→ Em produção, substitua `Access-Control-Allow-Origin: *` pelo domínio real do seu frontend em `index.php`

**Sessão expirando rápido**
→ Mude o `+7 days` em `api/auth.php` na função `gerarToken()`
