<?php
// ============================================
// middleware/auth.php — Valida token Bearer
// ============================================

require_once __DIR__ . '/../config/db.php';

function autenticar(): int {
    $headers    = getallheaders();
    $authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? '';

    if (!str_starts_with($authHeader, 'Bearer ')) {
        jsonErro(401, 'Token não fornecido. Faça login.');
    }

    $token = trim(substr($authHeader, 7));
    $db    = getDB();

    $stmt = $db->prepare('SELECT usuario_id, expira_em FROM sessoes WHERE token = ?');
    $stmt->execute([$token]);
    $sessao = $stmt->fetch();

    if (!$sessao) jsonErro(401, 'Token inválido.');

    if (new DateTime($sessao['expira_em']) < new DateTime()) {
        $db->prepare('DELETE FROM sessoes WHERE token = ?')->execute([$token]);
        jsonErro(401, 'Sessão expirada. Faça login novamente.');
    }

    return (int) $sessao['usuario_id'];
}
