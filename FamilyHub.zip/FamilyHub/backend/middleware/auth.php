<?php
// ============================================
// middleware/auth.php — Valida token Bearer
// ============================================
// "Middleware" é um conceito de software que fica no meio do caminho:
// toda requisição que precisa de autenticação passa por aqui ANTES
// de chegar na lógica principal (atividades, membros, etc.)
// Se o token for inválido ou expirado, a requisição é bloqueada aqui mesmo.

// Inclui o arquivo de conexão com o banco (necessário para consultar a tabela sessoes)
// require_once garante que o arquivo seja incluído apenas uma vez, evitando redeclarações
require_once __DIR__ . '/../config/db.php';

// ─── FUNÇÃO: autenticar() ─────────────────────────────────────────
// Verifica se a requisição HTTP possui um token Bearer válido.
// Retorna o ID do usuário autenticado (int) se tudo estiver correto.
// Em caso de falha, chama jsonErro() e encerra a execução imediatamente.
function autenticar(): int {

    // Lê todos os cabeçalhos HTTP da requisição atual.
    // getallheaders() retorna um array como ['Authorization' => 'Bearer abc123...']
    $headers    = getallheaders();

    // Tenta obter o cabeçalho Authorization de duas formas:
    // 'Authorization' (capitalizado, padrão) ou 'authorization' (minúsculo, alguns servidores)
    // O operador ?? retorna o primeiro valor não-nulo encontrado, ou '' se nenhum existir.
    $authHeader = $headers['Authorization'] ?? $headers['authorization'] ?? '';

    // Verifica se o cabeçalho começa exatamente com 'Bearer '
    // O padrão OAuth 2.0 exige esse prefixo para tokens de acesso
    if (!str_starts_with($authHeader, 'Bearer ')) {
        // Se não tiver o token, bloqueia com HTTP 401 (Não Autorizado)
        jsonErro(401, 'Token não fornecido. Faça login.');
    }

    // Extrai apenas o token, removendo o prefixo 'Bearer ' (7 caracteres)
    // trim() remove espaços extras que possam ter sido adicionados acidentalmente
    $token = trim(substr($authHeader, 7));

    // Obtém a conexão com o banco de dados (singleton)
    $db    = getDB();

    // Prepared statement: busca na tabela sessoes o registro com o token recebido.
    // O ? é um placeholder seguro — substitui o valor SEM risco de SQL Injection.
    // Busca apenas usuario_id e expira_em, que são os únicos campos necessários.
    $stmt = $db->prepare('SELECT usuario_id, expira_em FROM sessoes WHERE token = ?');
    $stmt->execute([$token]); // Executa passando o token como parâmetro seguro
    $sessao = $stmt->fetch(); // Retorna o registro como array associativo, ou false se não encontrar

    // Se não encontrou o token no banco, ele é inválido (pode ser forjado ou já deletado)
    if (!$sessao) jsonErro(401, 'Token inválido.');

    // Compara a data de expiração da sessão com a data/hora atual.
    // new DateTime($sessao['expira_em']) converte a string do banco em objeto DateTime.
    // new DateTime() sem parâmetro = agora.
    // Se "expira_em" for anterior a agora, a sessão está vencida.
    if (new DateTime($sessao['expira_em']) < new DateTime()) {
        // Remove o token expirado do banco (limpeza automática)
        $db->prepare('DELETE FROM sessoes WHERE token = ?')->execute([$token]);
        // Bloqueia a requisição com HTTP 401 informando que a sessão expirou
        jsonErro(401, 'Sessão expirada. Faça login novamente.');
    }

    // Se chegou até aqui, o token é válido e não expirou.
    // Retorna o ID do usuário como inteiro para ser usado pela função que chamou autenticar()
    return (int) $sessao['usuario_id'];
}
