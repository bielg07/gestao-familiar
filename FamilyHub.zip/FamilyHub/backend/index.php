<?php
// ============================================
// index.php — Roteador principal da API
// ============================================
// Este é o PONTO DE ENTRADA de toda a API.
// Todas as requisições HTTP chegam aqui primeiro.
// O roteador lê a URL, identifica qual recurso foi pedido
// e delega para o arquivo PHP específico daquele recurso.
//
// Uso: index.php?rota=/auth/login (compatível com XAMPP sem mod_rewrite)
// ============================================

// ─── CABEÇALHOS CORS ──────────────────────────────────────────────
// CORS (Cross-Origin Resource Sharing): permite que o frontend
// (rodando em um domínio/porta diferente) faça requisições à esta API.
// Sem esses cabeçalhos, o navegador bloquearia as requisições por segurança.

// Permite requisições de QUALQUER origem (*).
// Em produção, substitua por uma origem específica: 'https://seusite.com'
header('Access-Control-Allow-Origin: *');

// Lista os métodos HTTP que esta API aceita
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');

// Permite que o frontend envie estes cabeçalhos nas requisições:
// Content-Type: indica que o corpo é JSON
// Authorization: carrega o token Bearer de autenticação
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Define que todas as respostas desta API serão em JSON com codificação UTF-8
header('Content-Type: application/json; charset=utf-8');

// ─── PREFLIGHT CORS (OPTIONS) ─────────────────────────────────────
// Antes de enviar uma requisição real (POST, PUT, DELETE),
// o navegador envia uma requisição "preflight" do tipo OPTIONS
// para verificar se o servidor aceita a operação.
// Respondemos com 204 (No Content) e encerramos imediatamente.
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204); // 204 = sucesso sem corpo de resposta
    exit;
}

// ─── FUNÇÕES DE RESPOSTA JSON ─────────────────────────────────────
// Essas duas funções são usadas por TODOS os arquivos do backend
// para enviar respostas padronizadas.

// jsonOk(): envia uma resposta de SUCESSO
// $data: o dado a ser retornado (array, objeto, string, etc.)
// $code: código HTTP de sucesso (padrão 200; 201 para criação)
// never: declaração de tipo que indica que a função nunca retorna — sempre chama exit()
function jsonOk(mixed $data, int $code = 200): never {
    http_response_code($code); // Define o código HTTP da resposta
    // json_encode converte o array PHP em string JSON
    // JSON_UNESCAPED_UNICODE: não escapa caracteres especiais (ex: ã, é, ç ficam legíveis)
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit; // Encerra a execução imediatamente após enviar a resposta
}

// jsonErro(): envia uma resposta de ERRO padronizada
// $code: código HTTP de erro (400, 401, 404, 405, 409, 500, etc.)
// $msg: mensagem descritiva do erro para exibir ao frontend
function jsonErro(int $code, string $msg): never {
    http_response_code($code);
    // Retorna sempre um objeto JSON com a chave "erro" contendo a mensagem
    echo json_encode(['erro' => $msg], JSON_UNESCAPED_UNICODE);
    exit;
}

// ─── LEITURA DO CORPO DA REQUISIÇÃO ──────────────────────────────
// php://input é um stream especial que contém o corpo bruto da requisição HTTP.
// file_get_contents() lê esse stream como string.
// json_decode() converte o JSON recebido em array PHP associativo (true = array, não objeto).
// O ?? [] garante que, se o corpo estiver vazio ou não for JSON válido, usa array vazio.
$GLOBALS['body'] = json_decode(file_get_contents('php://input'), true) ?? [];

// ─── ANÁLISE DA ROTA ──────────────────────────────────────────────
// Lê o parâmetro ?rota= da URL. Exemplo: ?rota=/atividades/5
// Se não informado, assume '/' (raiz)
$uri    = $_GET['rota'] ?? '/';

// Remove barras do início e do fim: '/atividades/5' → 'atividades/5'
$uri    = trim($uri, '/');

// Divide a string em partes pelo separador '/':
// 'atividades/5' → ['atividades', '5']
// Se uri estiver vazio, $partes = []
$partes = $uri ? explode('/', $uri) : [];

// $recurso: primeiro segmento da URL — identifica qual "recurso" foi pedido
// Ex: 'auth', 'membros', 'atividades', 'dashboard'
$GLOBALS['recurso'] = $partes[0] ?? '';

// $id: segundo segmento, mas SOMENTE se for numérico (dígitos apenas)
// ctype_digit() verifica isso. Ex: 'atividades/5' → id = 5; 'atividades/login' → id = null
$GLOBALS['id']      = isset($partes[1]) && ctype_digit($partes[1]) ? (int)$partes[1] : null;

// $sub: segundo segmento como string pura (sem verificar se é número)
// Usado para sub-rotas textuais como 'auth/login', 'auth/cadastro', 'auth/me'
$GLOBALS['sub']     = $partes[1] ?? '';

// $method: o método HTTP da requisição (GET, POST, PUT, DELETE)
$GLOBALS['method']  = $_SERVER['REQUEST_METHOD'];

// ─── ROTEAMENTO PRINCIPAL ─────────────────────────────────────────
// switch compara o recurso identificado na URL e inclui
// o arquivo PHP responsável por tratar aquele recurso.
// require: inclui e executa o arquivo; se não encontrar, lança erro fatal.
switch ($GLOBALS['recurso']) {
    case 'auth':       // Rotas: /auth/login, /auth/cadastro, /auth/logout, /auth/me
        require __DIR__ . '/api/auth.php';
        break;

    case 'membros':    // Rotas: GET/POST /membros, PUT/DELETE /membros/{id}
        require __DIR__ . '/api/membros.php';
        break;

    case 'atividades': // Rotas: GET/POST /atividades, PUT/DELETE /atividades/{id}
        require __DIR__ . '/api/atividades.php';
        break;

    case 'dashboard':  // Rota: GET /dashboard (estatísticas para a tela inicial)
        require __DIR__ . '/api/dashboard.php';
        break;

    default:
        // Se o recurso não for nenhum dos acima, retorna 404 (Not Found)
        // com uma mensagem indicando qual rota não foi encontrada
        jsonErro(404, "Rota '/{$GLOBALS['recurso']}' não encontrada.");
}
