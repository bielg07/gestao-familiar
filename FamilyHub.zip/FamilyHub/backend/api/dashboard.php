<?php
// ============================================
// api/dashboard.php — Estatísticas da tela inicial
// ============================================
// Retorna em uma única requisição todos os dados
// necessários para popular o Dashboard do frontend:
// - Contagem de atividades por categoria
// - Total geral de atividades
// - Próximas 5 atividades futuras não concluídas
// - Lista de membros com quantidade de atividades de cada um
//
// Rota: GET /api/dashboard

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../middleware/auth.php';

// Bloqueia métodos diferentes de GET (ex: POST, PUT, DELETE)
// O dashboard só fornece dados — não cria nem altera nada
if ($GLOBALS['method'] !== 'GET') jsonErro(405, 'Método não permitido.');

// Valida o token e obtém o ID do usuário logado
$userId = autenticar();
$db     = getDB();

// ─── 1. CONTAGEM POR CATEGORIA ────────────────────────────────────
// Agrupa as atividades do usuário por categoria e conta quantas há em cada grupo.
// GROUP BY categoria: agrupa as linhas que têm a mesma categoria
// COUNT(*): conta quantas linhas existem em cada grupo
$cats = $db->prepare('SELECT categoria, COUNT(*) as total FROM atividades WHERE usuario_id = ? GROUP BY categoria');
$cats->execute([$userId]);

// array_column() reorganiza o array de resultados:
// Antes: [['categoria'=>'escolar','total'=>5], ['categoria'=>'esporte','total'=>3]]
// Depois (com array_column($arr, 'total', 'categoria')): ['escolar'=>5, 'esporte'=>3]
// Isso permite acessar diretamente $porCategoria['escolar'] em vez de iterar o array
$porCategoria = array_column($cats->fetchAll(), 'total', 'categoria');

// ─── 2. TOTAL GERAL DE ATIVIDADES ─────────────────────────────────
// Conta TODAS as atividades do usuário (sem filtro de categoria ou status)
$totalStmt = $db->prepare('SELECT COUNT(*) FROM atividades WHERE usuario_id = ?');
$totalStmt->execute([$userId]);
// fetchColumn() retorna apenas o valor da primeira coluna da primeira linha
// (int) converte string para inteiro (o MySQL retorna strings por padrão com COUNT)
$total = (int) $totalStmt->fetchColumn();

// ─── 3. PRÓXIMAS 5 ATIVIDADES ─────────────────────────────────────
// Busca as 5 próximas atividades do usuário que:
// - Não estejam concluídas (status != 'concluida')
// - Tenham data e hora no futuro (CONCAT(data, ' ', hora) >= NOW())
//   CONCAT une data e hora em uma string de DATETIME para comparar com NOW()
// - Ordenadas pela mais próxima primeiro (ORDER BY data ASC, hora ASC)
// - Limite de 5 registros (LIMIT 5)
$proxStmt = $db->prepare('
    SELECT a.id, a.titulo, a.categoria, a.status, a.data, a.hora
    FROM atividades a
    WHERE a.usuario_id = ?
      AND a.status != \'concluida\'
      AND CONCAT(a.data, \' \', a.hora) >= NOW()
    ORDER BY a.data ASC, a.hora ASC
    LIMIT 5
');
$proxStmt->execute([$userId]);

// Processa cada atividade próxima:
$proximas = array_map(fn($r) => [
    'id'        => (string)$r['id'],           // ID como string (segurança no JavaScript)
    'titulo'    => $r['titulo'],
    'categoria' => $r['categoria'],
    'status'    => $r['status'],
    'data'      => $r['data'],                 // Formato AAAA-MM-DD vindo do MySQL
    'hora'      => substr($r['hora'], 0, 5),   // MySQL retorna HH:MM:SS; substr corta para HH:MM
], $proxStmt->fetchAll());

// ─── 4. MEMBROS COM CONTAGEM DE ATIVIDADES ───────────────────────
// Lista todos os membros do usuário com a quantidade de atividades de cada um.
// LEFT JOIN: inclui membros que NÃO têm nenhuma atividade (qtd_atividades = 0)
//   (INNER JOIN excluiria esses membros)
// COUNT(am.atividade_id): conta apenas os vínculos que existem (NULL não é contado)
// GROUP BY m.id: agrupa por membro para contar separadamente
$membStmt = $db->prepare('
    SELECT m.id, m.nome, m.papel, m.cor,
           COUNT(am.atividade_id) as qtd_atividades
    FROM membros m
    LEFT JOIN atividade_membros am ON am.membro_id = m.id
    WHERE m.usuario_id = ?
    GROUP BY m.id
    ORDER BY m.nome ASC
');
$membStmt->execute([$userId]);

$membrosDash = array_map(fn($r) => [
    'id'             => (string)$r['id'],
    'nome'           => $r['nome'],
    'papel'          => $r['papel'],
    'cor'            => $r['cor'],
    'qtd_atividades' => (int)$r['qtd_atividades'], // Converte para int (COUNT retorna string)
], $membStmt->fetchAll());

// ─── RESPOSTA FINAL ──────────────────────────────────────────────
// Retorna um único objeto JSON com todos os dados do dashboard.
// O frontend faz UMA requisição e recebe tudo de uma vez (performance).
jsonOk([
    'categorias' => [
        'escolar' => (int)($porCategoria['escolar'] ?? 0), // ?? 0 = retorna 0 se a categoria não tiver nenhuma atividade
        'esporte' => (int)($porCategoria['esporte'] ?? 0),
        'social'  => (int)($porCategoria['social']  ?? 0),
    ],
    'total'    => $total,    // Número total de atividades
    'proximas' => $proximas, // Array das 5 próximas atividades
    'membros'  => $membrosDash, // Array de membros com contagem
]);
