<?php
// ============================================
// api/atividades.php — CRUD de Atividades
// ============================================
// Gerencia todas as operações de atividades da família.
// Suporta filtros avançados na listagem e vínculos com membros (N:N).
//
// Rotas:
// GET    /api/atividades              → lista (com filtros opcionais via query string)
// POST   /api/atividades              → cria nova atividade
// PUT    /api/atividades/{id}         → atualiza atividade existente
// DELETE /api/atividades/{id}         → remove atividade

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../middleware/auth.php';

// Valida token e obtém ID do usuário — bloqueia requisições sem autenticação
$userId = autenticar();
$method = $GLOBALS['method'];
$id     = $GLOBALS['id'];   // ID numérico da URL, ou null se não informado
$body   = $GLOBALS['body'];
$db     = getDB();

// Despacha para a função correta de acordo com o método HTTP
match ($method) {
    'GET'    => listar($db, $userId),
    'POST'   => criar($db, $userId, $body),
    'PUT'    => atualizar($db, $userId, $id, $body),
    'DELETE' => excluir($db, $userId, $id),
    default  => jsonErro(405, 'Método não permitido.')
};

// ─── FUNÇÃO: listar() ─────────────────────────────────────────────
// Lista atividades do usuário com filtros dinâmicos opcionais.
// Os filtros são passados como parâmetros na URL (query string):
// Ex: GET /atividades?status=pendente&categoria=escolar&nome=natação
function listar(PDO $db, int $userId): void {

    // Começa sempre com o filtro obrigatório: só atividades do usuário logado
    $where  = ['a.usuario_id = :uid'];
    $params = [':uid' => $userId];

    // ── Filtros opcionais (cada um só é adicionado se estiver na URL) ──

    // Filtra por status: pendente, em andamento, concluida
    if (!empty($_GET['status'])) {
        $where[]           = 'a.status = :status';
        $params[':status'] = $_GET['status'];
    }

    // Filtra por categoria: escolar, esporte, social
    if (!empty($_GET['categoria'])) {
        $where[]              = 'a.categoria = :categoria';
        $params[':categoria'] = $_GET['categoria'];
    }

    // Filtra por prioridade: urgente, pouco urgente, nao urgente
    if (!empty($_GET['prioridade'])) {
        $where[]               = 'a.prioridade = :prioridade';
        $params[':prioridade'] = $_GET['prioridade'];
    }

    // Filtra por texto no título (busca parcial):
    // LIKE com % dos dois lados = "contém" (ex: "nata" encontra "Natação Infantil")
    if (!empty($_GET['nome'])) {
        $where[]         = 'a.titulo LIKE :nome';
        $params[':nome'] = '%' . $_GET['nome'] . '%'; // % = qualquer sequência de caracteres
    }

    // Filtra por data mínima: mostra apenas atividades a partir de uma data
    if (!empty($_GET['data_inicio'])) {
        $where[]                = 'a.data >= :data_inicio';
        $params[':data_inicio'] = $_GET['data_inicio'];
    }

    // Filtra por membro vinculado:
    // EXISTS: verifica se existe pelo menos um registro na tabela atividade_membros
    // que ligue esta atividade ao membro_id informado.
    // Mais eficiente que JOIN quando queremos apenas verificar existência.
    if (!empty($_GET['membro_id'])) {
        $where[]              = 'EXISTS (SELECT 1 FROM atividade_membros am WHERE am.atividade_id = a.id AND am.membro_id = :membro_id)';
        $params[':membro_id'] = (int)$_GET['membro_id'];
    }

    // ── Monta a query dinamicamente ──────────────────────────────
    // implode() une todos os fragmentos WHERE com ' AND ' entre eles
    // Ex: ['a.usuario_id = :uid', 'a.status = :status'] → 'a.usuario_id = :uid AND a.status = :status'
    $sql = '
        SELECT a.id, a.titulo, a.descricao, a.categoria, a.status, a.prioridade, a.data, a.hora
        FROM atividades a
        WHERE ' . implode(' AND ', $where) . '
        ORDER BY
            FIELD(a.prioridade, "urgente", "pouco urgente", "nao urgente"),
            -- FIELD() define a ordem de uma coluna ENUM manualmente:
            -- "urgente" aparece primeiro (1), depois "pouco urgente" (2), depois "nao urgente" (3)
            a.data ASC, a.hora ASC
            -- Dentro da mesma prioridade, ordena por data e hora crescente
    ';

    $stmt = $db->prepare($sql);
    $stmt->execute($params); // Parâmetros nomeados (:uid, :status, etc.) são mais legíveis que ?
    $rows = $stmt->fetchAll();

    // ── Para cada atividade, busca os membros vinculados ──────────
    $atividades = [];
    foreach ($rows as $row) {
        // Consulta separada para buscar os IDs dos membros desta atividade
        // (relação N:N via tabela atividade_membros)
        $memStmt = $db->prepare('
            SELECT m.id FROM atividade_membros am
            JOIN membros m ON m.id = am.membro_id
            WHERE am.atividade_id = ?
        ');
        $memStmt->execute([$row['id']]);
        $membs = $memStmt->fetchAll(); // Array de ['id' => X]

        $atividades[] = [
            'id'         => (string) $row['id'],       // ID como string (segurança JS)
            'titulo'     => $row['titulo'],
            'descricao'  => $row['descricao'] ?? '',   // NULL → string vazia
            'categoria'  => $row['categoria'],
            'status'     => $row['status'],
            'prioridade' => $row['prioridade'],
            'data'       => $row['data'],
            'hora'       => substr($row['hora'], 0, 5), // HH:MM:SS → HH:MM
            // array_map extrai apenas os IDs dos membros como array de strings
            'membrosIds' => array_map(fn($m) => (string)$m['id'], $membs),
        ];
    }

    jsonOk($atividades);
}

// ─── FUNÇÃO: criar() ──────────────────────────────────────────────
// Insere uma nova atividade no banco e vincula os membros selecionados.
function criar(PDO $db, int $userId, array $body): void {
    // validarBody() valida e sanitiza todos os campos — lança jsonErro se inválido
    $dados = validarBody($body);

    $stmt = $db->prepare('
        INSERT INTO atividades (usuario_id, titulo, descricao, categoria, status, prioridade, data, hora)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ');
    $stmt->execute([
        $userId, $dados['titulo'], $dados['descricao'], $dados['categoria'],
        $dados['status'], $dados['prioridade'], $dados['data'], $dados['hora'],
    ]);
    $novoId = (int) $db->lastInsertId(); // ID gerado automaticamente pelo banco

    // Vincula os membros selecionados na tabela de relacionamento N:N
    salvarMembros($db, $novoId, $userId, $dados['membrosIds']);

    // buscarPorId() retorna o registro completo já formatado (inclui membrosIds)
    // Retorna HTTP 201 (Created) com os dados da atividade criada
    jsonOk(buscarPorId($db, $novoId, $userId), 201);
}

// ─── FUNÇÃO: atualizar() ──────────────────────────────────────────
// Atualiza todos os campos de uma atividade existente e redefine os membros vinculados.
function atualizar(PDO $db, int $userId, ?int $id, array $body): void {
    if (!$id) jsonErro(400, 'ID da atividade não informado.');

    // checarPropriedade() verifica se a atividade existe E pertence ao usuário logado
    checarPropriedade($db, $id, $userId);

    $dados = validarBody($body); // Valida os novos dados

    // Atualiza todos os campos da atividade + registra timestamp de atualização
    $db->prepare('
        UPDATE atividades
        SET titulo = ?, descricao = ?, categoria = ?, status = ?, prioridade = ?, data = ?, hora = ?, atualizado_em = NOW()
        WHERE id = ?
    ')->execute([
        $dados['titulo'], $dados['descricao'], $dados['categoria'],
        $dados['status'], $dados['prioridade'], $dados['data'], $dados['hora'], $id,
    ]);

    // Estratégia "delete and re-insert" para os membros:
    // Remove TODOS os vínculos atuais desta atividade...
    $db->prepare('DELETE FROM atividade_membros WHERE atividade_id = ?')->execute([$id]);
    // ...e recria com a nova lista de membros selecionados.
    // Mais simples que calcular quem foi adicionado/removido.
    salvarMembros($db, $id, $userId, $dados['membrosIds']);

    jsonOk(buscarPorId($db, $id, $userId)); // Retorna dados atualizados
}

// ─── FUNÇÃO: excluir() ────────────────────────────────────────────
// Remove uma atividade. O CASCADE no banco remove automaticamente
// os vínculos na tabela atividade_membros.
function excluir(PDO $db, int $userId, ?int $id): void {
    if (!$id) jsonErro(400, 'ID da atividade não informado.');

    // checarPropriedade() retorna os dados da atividade (incluindo título para a mensagem)
    $atv = checarPropriedade($db, $id, $userId);

    $db->prepare('DELETE FROM atividades WHERE id = ?')->execute([$id]);

    // Mensagem de confirmação com o título da atividade removida
    jsonOk(['mensagem' => "Atividade '{$atv['titulo']}' removida."]);
}

// ─── FUNÇÃO AUXILIAR: validarBody() ──────────────────────────────
// Valida e sanitiza todos os campos de uma requisição de criação/edição.
// Centraliza as validações em um único lugar (evita repetição em criar() e atualizar()).
// Retorna um array limpo com todos os campos validados.
function validarBody(array $body): array {
    $titulo     = trim($body['titulo']     ?? '');
    $descricao  = trim($body['descricao']  ?? ''); // Opcional: não lança erro se vazio
    $categoria  = $body['categoria']  ?? '';
    $status     = $body['status']     ?? 'pendente';     // Padrão: pendente
    $prioridade = $body['prioridade'] ?? 'nao urgente';  // Padrão: não urgente
    $data       = $body['data']       ?? '';
    $hora       = $body['hora']       ?? '';

    // Processa a lista de IDs de membros:
    // array_map('intval', ...) converte todos os valores para inteiro
    // array_filter(..., fn($v) => $v > 0) remove zeros e negativos (IDs inválidos)
    $membrosIds = array_filter(
        array_map('intval', (array)($body['membrosIds'] ?? [])),
        fn($v) => $v > 0
    );

    // ── Validações de campos obrigatórios ────────────────────────
    if (!$titulo) jsonErro(400, 'Título é obrigatório.');
    if (!$data)   jsonErro(400, 'Data é obrigatória.');
    if (!$hora)   jsonErro(400, 'Hora é obrigatória.');

    // ── Validações de valores permitidos (whitelist) ──────────────
    // in_array() verifica se o valor está na lista de valores válidos.
    // Usar whitelist é mais seguro que tentar "limpar" valores inválidos.
    if (!in_array($categoria,  ['escolar','esporte','social']))               jsonErro(400, 'Categoria inválida.');
    if (!in_array($status,     ['pendente','em andamento','concluida']))       jsonErro(400, 'Status inválido.');
    if (!in_array($prioridade, ['urgente','pouco urgente','nao urgente']))     jsonErro(400, 'Prioridade inválida.');

    // ── Validações de formato via regex ──────────────────────────
    // Data deve ser exatamente: 4 dígitos - 2 dígitos - 2 dígitos (ex: 2026-02-19)
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $data)) jsonErro(400, 'Formato de data inválido.');
    // Hora deve ser exatamente: 2 dígitos : 2 dígitos (ex: 14:30)
    if (!preg_match('/^\d{2}:\d{2}$/', $hora))        jsonErro(400, 'Formato de hora inválido.');

    // compact() cria um array associativo com as variáveis listadas pelo nome
    // Equivale a: ['titulo' => $titulo, 'descricao' => $descricao, ...]
    return compact('titulo','descricao','categoria','status','prioridade','data','hora','membrosIds');
}

// ─── FUNÇÃO AUXILIAR: salvarMembros() ────────────────────────────
// Vincula membros a uma atividade na tabela de relacionamento N:N.
// Só insere membros que realmente pertencem ao usuário (verificação de segurança).
function salvarMembros(PDO $db, int $atividadeId, int $userId, array $membrosIds): void {
    if (empty($membrosIds)) return; // Nenhum membro a vincular: encerra sem fazer nada

    // Cria placeholders dinamicamente: se $membrosIds = [1, 2, 3], gera '?, ?, ?'
    // array_fill(0, count, '?') cria um array de N elementos com valor '?'
    $placeholders = implode(',', array_fill(0, count($membrosIds), '?'));

    // Consulta com IN(...): verifica quais dos IDs recebidos são membros válidos do usuário
    // ...$membrosIds "espalha" o array como argumentos individuais (spread operator)
    // Adiciona $userId no final para o filtro AND usuario_id = ?
    $check = $db->prepare("SELECT id FROM membros WHERE id IN ($placeholders) AND usuario_id = ?");
    $check->execute([...$membrosIds, $userId]);

    // array_column() extrai apenas a coluna 'id' do resultado
    $validos = array_column($check->fetchAll(), 'id');

    // INSERT IGNORE: se o par (atividade_id, membro_id) já existir (PRIMARY KEY duplicada),
    // o banco ignora silenciosamente em vez de lançar erro
    $stmt = $db->prepare('INSERT IGNORE INTO atividade_membros (atividade_id, membro_id) VALUES (?, ?)');
    foreach ($validos as $mid) {
        $stmt->execute([$atividadeId, $mid]); // Insere um vínculo por vez
    }
}

// ─── FUNÇÃO AUXILIAR: buscarPorId() ──────────────────────────────
// Busca uma atividade completa (com membrosIds) pelo ID.
// Usado após criar() e atualizar() para retornar os dados atualizados ao frontend.
function buscarPorId(PDO $db, int $id, int $userId): array {
    $stmt = $db->prepare('SELECT id, titulo, descricao, categoria, status, prioridade, data, hora FROM atividades WHERE id = ? AND usuario_id = ?');
    $stmt->execute([$id, $userId]);
    $row = $stmt->fetch();
    if (!$row) jsonErro(404, 'Atividade não encontrada.');

    // Busca os IDs dos membros vinculados a esta atividade
    $memStmt = $db->prepare('SELECT membro_id FROM atividade_membros WHERE atividade_id = ?');
    $memStmt->execute([$id]);
    // Extrai apenas os IDs como array de strings
    $membrosIds = array_map(fn($r) => (string)$r['membro_id'], $memStmt->fetchAll());

    return [
        'id'         => (string) $row['id'],
        'titulo'     => $row['titulo'],
        'descricao'  => $row['descricao'] ?? '',
        'categoria'  => $row['categoria'],
        'status'     => $row['status'],
        'prioridade' => $row['prioridade'],
        'data'       => $row['data'],
        'hora'       => substr($row['hora'], 0, 5), // HH:MM:SS → HH:MM
        'membrosIds' => $membrosIds,
    ];
}

// ─── FUNÇÃO AUXILIAR: checarPropriedade() ────────────────────────
// Verifica se a atividade existe E pertence ao usuário logado.
// Proteção essencial contra um usuário acessar dados de outro.
// Retorna os dados básicos da atividade (id e titulo) ou lança erro 404.
function checarPropriedade(PDO $db, int $id, int $userId): array {
    $stmt = $db->prepare('SELECT id, titulo FROM atividades WHERE id = ? AND usuario_id = ?');
    $stmt->execute([$id, $userId]);
    $atv = $stmt->fetch();
    // Retorna 404 propositalmente mesmo se a atividade existir mas for de outro usuário
    // (não informar ao usuário mal-intencionado se o ID existe no sistema)
    if (!$atv) jsonErro(404, 'Atividade não encontrada.');
    return $atv;
}
