<?php
// ============================================
// api/membros.php — CRUD de Membros da Família
// ============================================
// CRUD = Create, Read, Update, Delete
// Este arquivo gerencia os membros da família vinculados ao usuário logado.
// Todas as operações exigem autenticação e só afetam os dados do próprio usuário.
//
// Rotas disponíveis:
// GET    /api/membros          → lista todos os membros do usuário logado
// POST   /api/membros          → cria novo membro { nome, papel, cor }
// PUT    /api/membros/{id}     → atualiza dados de um membro { nome, papel, cor }
// DELETE /api/membros/{id}     → remove permanentemente um membro

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../middleware/auth.php';

// autenticar() valida o token Bearer e retorna o ID do usuário logado.
// Se o token for inválido, encerra aqui com erro 401.
// Isso garante que NENHUMA operação abaixo execute sem autenticação.
$userId = autenticar();

$method = $GLOBALS['method']; // GET, POST, PUT ou DELETE
$id     = $GLOBALS['id'];     // ID numérico da URL (ex: /membros/3 → id = 3), ou null
$body   = $GLOBALS['body'];   // Corpo JSON da requisição decodificado
$db     = getDB();             // Conexão PDO com o banco (singleton)

// ─── DESPACHO POR MÉTODO HTTP ─────────────────────────────────────
// match() é equivalente ao switch, mas mais estrito (comparação idêntica ===).
// Cada método HTTP corresponde a uma operação do CRUD:
// GET    → Leitura (Read)
// POST   → Criação (Create)
// PUT    → Atualização (Update)
// DELETE → Remoção (Delete)
match ($method) {
    'GET'    => listar($db, $userId),              // Lista todos os membros do usuário
    'POST'   => criar($db, $userId, $body),        // Cria um novo membro
    'PUT'    => atualizar($db, $userId, $id, $body), // Atualiza membro pelo ID
    'DELETE' => excluir($db, $userId, $id),        // Remove membro pelo ID
    default  => jsonErro(405, 'Método não permitido.') // 405 = Method Not Allowed
};

// ─── FUNÇÃO: listar() ─────────────────────────────────────────────
// Retorna todos os membros cadastrados pelo usuário logado,
// ordenados alfabeticamente pelo nome.
function listar(PDO $db, int $userId): void {
    $stmt = $db->prepare('
        SELECT id, nome, papel, cor
        FROM membros
        WHERE usuario_id = ?   -- Filtra APENAS os membros deste usuário (isolamento de dados)
        ORDER BY nome ASC      -- Ordena em ordem alfabética crescente
    ');
    $stmt->execute([$userId]);
    $rows = $stmt->fetchAll(); // fetchAll() retorna todos os registros como array de arrays

    // Transforma o resultado para ajustar tipos de dados:
    // array_map() aplica uma função a cada item do array $rows
    // fn($r) => [...] é uma arrow function (sintaxe curta de closure no PHP 7.4+)
    $membros = array_map(fn($r) => [
        'id'    => (string) $r['id'],  // Converte ID para string: o JavaScript trata IDs grandes
                                       // como floats, perdendo precisão; string é mais seguro
        'nome'  => $r['nome'],         // Nome do membro (já é string)
        'papel' => $r['papel'],        // Papel/função na família (já é string)
        'cor'   => $r['cor'],          // Cor HEX do avatar (já é string)
    ], $rows);

    jsonOk($membros); // Retorna o array de membros como JSON com HTTP 200
}

// ─── FUNÇÃO: criar() ──────────────────────────────────────────────
// Insere um novo membro da família no banco de dados.
function criar(PDO $db, int $userId, array $body): void {
    // Extrai e sanitiza os campos do corpo da requisição
    // trim() remove espaços no início e no fim da string
    // ?? '' garante string vazia se o campo não vier no JSON (evita erro de índice)
    $nome  = trim($body['nome']  ?? '');
    $papel = trim($body['papel'] ?? '');
    $cor   = trim($body['cor']   ?? '#6b9fff'); // Cor padrão: azul suave se não informada

    // Validação: nome e papel são obrigatórios
    if (!$nome || !$papel) jsonErro(400, 'Nome e papel são obrigatórios.');

    // Valida o formato da cor HEX usando expressão regular:
    // ^ = início da string
    // # = deve começar com #
    // [0-9a-fA-F]{6} = exatamente 6 caracteres hexadecimais (ex: ff5733, 4F8EF7)
    // $ = fim da string
    // Se inválida, usa a cor padrão azul
    if (!preg_match('/^#[0-9a-fA-F]{6}$/', $cor)) $cor = '#6b9fff';

    // Insere o novo membro no banco vinculado ao usuário logado
    $stmt = $db->prepare('INSERT INTO membros (usuario_id, nome, papel, cor) VALUES (?, ?, ?, ?)');
    $stmt->execute([$userId, $nome, $papel, $cor]);

    // lastInsertId() retorna o ID gerado pelo AUTO_INCREMENT para o registro recém-criado
    $novoId = (int) $db->lastInsertId();

    // Retorna os dados do membro criado com HTTP 201 (Created)
    jsonOk([
        'id'    => (string) $novoId, // ID como string (motivo explicado em listar())
        'nome'  => $nome,
        'papel' => $papel,
        'cor'   => $cor,
    ], 201);
}

// ─── FUNÇÃO: atualizar() ──────────────────────────────────────────
// Atualiza nome, papel e/ou cor de um membro existente.
// Verifica se o membro pertence ao usuário logado antes de alterar.
function atualizar(PDO $db, int $userId, ?int $id, array $body): void {
    // Verifica se o ID foi informado na URL (ex: PUT /membros/5 → id = 5)
    if (!$id) jsonErro(400, 'ID do membro não informado.');

    // VERIFICAÇÃO DE SEGURANÇA: garante que o membro com este ID
    // pertence ao usuário logado. Evita que um usuário edite membros de outro.
    // Consulta com DOIS filtros: id E usuario_id — ambos devem bater.
    $check = $db->prepare('SELECT id FROM membros WHERE id = ? AND usuario_id = ?');
    $check->execute([$id, $userId]);
    if (!$check->fetch()) jsonErro(404, 'Membro não encontrado.'); // 404 mesmo se existir mas for de outro usuário

    // Extrai e sanitiza os novos valores
    $nome  = trim($body['nome']  ?? '');
    $papel = trim($body['papel'] ?? '');
    $cor   = trim($body['cor']   ?? '#6b9fff');

    if (!$nome || !$papel) jsonErro(400, 'Nome e papel são obrigatórios.');
    if (!preg_match('/^#[0-9a-fA-F]{6}$/', $cor)) $cor = '#6b9fff'; // Fallback para cor padrão

    // Atualiza os três campos do membro identificado pelo ID
    $db->prepare('UPDATE membros SET nome = ?, papel = ?, cor = ? WHERE id = ?')->execute([$nome, $papel, $cor, $id]);

    // Retorna os dados atualizados do membro com HTTP 200
    jsonOk(['id' => (string)$id, 'nome' => $nome, 'papel' => $papel, 'cor' => $cor]);
}

// ─── FUNÇÃO: excluir() ────────────────────────────────────────────
// Remove permanentemente um membro do banco de dados.
// Graças ao CASCADE no banco, os vínculos na tabela atividade_membros
// são removidos automaticamente junto.
function excluir(PDO $db, int $userId, ?int $id): void {
    if (!$id) jsonErro(400, 'ID do membro não informado.');

    // Verifica se o membro existe E pertence ao usuário logado
    // Também recupera o nome para usar na mensagem de confirmação
    $check = $db->prepare('SELECT nome FROM membros WHERE id = ? AND usuario_id = ?');
    $check->execute([$id, $userId]);
    $membro = $check->fetch();
    if (!$membro) jsonErro(404, 'Membro não encontrado.');

    // Remove o membro permanentemente.
    // O ON DELETE CASCADE nas chaves estrangeiras do banco
    // remove automaticamente todas as entradas de atividade_membros
    // que referenciam este membro.
    $db->prepare('DELETE FROM membros WHERE id = ?')->execute([$id]);

    // Retorna mensagem confirmando a remoção com o nome do membro
    // (interpolação de string PHP com variável de array)
    jsonOk(['mensagem' => "Membro '{$membro['nome']}' removido."]);
}
