<?php
// ============================================
// api/auth.php — Autenticação
// ============================================
// Este arquivo trata todas as operações de autenticação do sistema.
// É chamado pelo roteador (index.php) quando a rota começa com /auth
//
// Rotas disponíveis:
// POST /api/auth/login    → faz login com email e senha
// POST /api/auth/cadastro → cria uma nova conta de usuário
// POST /api/auth/logout   → encerra a sessão (exige token Bearer)
// GET  /api/auth/me       → retorna os dados do usuário logado (exige token Bearer)

// Inclui a conexão com o banco (necessária para consultas ao MySQL)
require_once __DIR__ . '/../config/db.php';
// Inclui o middleware de autenticação (função autenticar())
require_once __DIR__ . '/../middleware/auth.php';

// Recupera as variáveis globais definidas pelo roteador (index.php)
$sub    = $GLOBALS['sub'];    // Sub-rota: 'login', 'cadastro', 'logout' ou 'me'
$method = $GLOBALS['method']; // Método HTTP: GET, POST, etc.
$body   = $GLOBALS['body'];   // Corpo da requisição já decodificado como array PHP

// ─── DESPACHO DE ROTAS ────────────────────────────────────────────
// Verifica o método HTTP + a sub-rota e chama a função correspondente.
// Cada if é independente; se nenhum bater, cai na linha de erro abaixo.
if ($method === 'POST' && $sub === 'login')    { login();    exit; }
if ($method === 'POST' && $sub === 'cadastro') { cadastro(); exit; }
if ($method === 'POST' && $sub === 'logout')   { logout();   exit; }
if ($method === 'GET'  && $sub === 'me')       { me();       exit; }

// Se chegou aqui, a combinação método+rota não existe
jsonErro(404, 'Rota de autenticação não encontrada.');

// ─── FUNÇÃO: login() ──────────────────────────────────────────────
// Autentica o usuário verificando e-mail e senha no banco.
// Em caso de sucesso, gera e retorna um token de sessão.
function login(): void {
    $body  = $GLOBALS['body'];          // Recupera o corpo da requisição
    $email = trim($body['email'] ?? ''); // Lê e remove espaços extras do e-mail
    $senha = $body['senha'] ?? '';       // Lê a senha (NÃO remover espaços: senhas podem ter espaços propositalmente)

    // Validação básica: ambos os campos são obrigatórios
    if (!$email || !$senha) jsonErro(400, 'E-mail e senha são obrigatórios.');

    $db   = getDB();

    // Busca o usuário pelo e-mail.
    // Traz apenas os campos necessários (boas práticas: nunca SELECT *)
    // Prepared statement com ? evita SQL Injection
    $stmt = $db->prepare('SELECT id, nome, email, senha_hash FROM usuarios WHERE email = ?');
    $stmt->execute([$email]);
    $user = $stmt->fetch(); // Retorna o usuário encontrado ou false

    // Dupla verificação de segurança:
    // 1. !$user: e-mail não existe no banco
    // 2. !password_verify($senha, $user['senha_hash']): senha incorreta
    // IMPORTANTE: password_verify() compara a senha em texto puro com o hash bcrypt
    // armazenado no banco — isso é seguro e não pode ser revertido para recuperar a senha original.
    // A mensagem de erro é PROPOSITALMENTE genérica: não informa se foi o e-mail ou a senha
    // que falhou (evita ataques de enumeração de usuários).
    if (!$user || !password_verify($senha, $user['senha_hash'])) {
        jsonErro(401, 'E-mail ou senha incorretos.');
    }

    // Gera um token de sessão e salva no banco
    $token = gerarToken($user['id']);

    // Retorna HTTP 200 com o token e os dados públicos do usuário
    // (sem senha_hash — nunca retornar dados sensíveis)
    jsonOk([
        'token'   => $token,
        'usuario' => [
            'id'    => $user['id'],
            'nome'  => $user['nome'],
            'email' => $user['email'],
        ]
    ]);
}

// ─── FUNÇÃO: cadastro() ───────────────────────────────────────────
// Cria uma nova conta de usuário no sistema.
// Valida os dados, verifica duplicidade de e-mail e salva com senha hasheada.
function cadastro(): void {
    $body  = $GLOBALS['body'];
    $nome  = trim($body['nome']  ?? '');  // Nome do usuário, sem espaços extras
    $email = trim($body['email'] ?? '');  // E-mail, sem espaços extras
    $senha = $body['senha'] ?? '';         // Senha (sem trim propositalmente)

    // Validação 1: todos os campos obrigatórios devem estar preenchidos
    if (!$nome || !$email || !$senha) jsonErro(400, 'Nome, e-mail e senha são obrigatórios.');

    // Validação 2: verifica se o e-mail tem formato válido (ex: usuario@dominio.com)
    // filter_var() com FILTER_VALIDATE_EMAIL usa regex interna do PHP
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) jsonErro(400, 'E-mail inválido.');

    // Validação 3: senha deve ter ao menos 6 caracteres (segurança mínima)
    if (strlen($senha) < 6) jsonErro(400, 'A senha deve ter ao menos 6 caracteres.');

    $db = getDB();

    // Verifica se já existe um usuário com este e-mail no banco.
    // Necessário porque a coluna email tem UNIQUE constraint,
    // mas checar antes gera uma mensagem de erro mais clara.
    $check = $db->prepare('SELECT id FROM usuarios WHERE email = ?');
    $check->execute([$email]);
    if ($check->fetch()) jsonErro(409, 'E-mail já cadastrado.'); // 409 = Conflict

    // Gera o hash bcrypt da senha.
    // password_hash() com PASSWORD_BCRYPT:
    // - Adiciona sal (salt) aleatório automaticamente
    // - É computacionalmente custoso (dificulta ataques de força bruta)
    // - O resultado é uma string de ~60 caracteres que inclui o algoritmo, custo e sal
    $hash = password_hash($senha, PASSWORD_BCRYPT);

    // Insere o novo usuário no banco com a senha hasheada (nunca em texto puro)
    $db->prepare('INSERT INTO usuarios (nome, email, senha_hash) VALUES (?, ?, ?)')->execute([$nome, $email, $hash]);

    // lastInsertId() retorna o ID gerado pelo AUTO_INCREMENT para o registro recém-inserido
    $userId = (int) $db->lastInsertId();

    // Já gera um token para o usuário recém-cadastrado
    // (assim ele não precisa fazer login logo após o cadastro)
    $token = gerarToken($userId);

    // Retorna HTTP 201 (Created) com o token e dados do novo usuário
    jsonOk([
        'token'   => $token,
        'usuario' => ['id' => $userId, 'nome' => $nome, 'email' => $email]
    ], 201);
}

// ─── FUNÇÃO: logout() ─────────────────────────────────────────────
// Encerra a sessão do usuário removendo o token do banco.
// Mesmo que o token seja inválido ou já expirado, retorna sucesso (comportamento seguro).
function logout(): void {
    $headers = getallheaders(); // Lê todos os cabeçalhos da requisição
    $auth    = $headers['Authorization'] ?? $headers['authorization'] ?? '';

    // Se houver um token Bearer no cabeçalho, remove-o do banco
    if (str_starts_with($auth, 'Bearer ')) {
        $token = trim(substr($auth, 7)); // Extrai o token (remove 'Bearer ')
        // DELETE remove a sessão — o token fica inválido a partir daqui
        getDB()->prepare('DELETE FROM sessoes WHERE token = ?')->execute([$token]);
    }

    // Sempre retorna sucesso, mesmo se o token não existia
    jsonOk(['mensagem' => 'Sessão encerrada.']);
}

// ─── FUNÇÃO: me() ─────────────────────────────────────────────────
// Retorna os dados do usuário atualmente autenticado.
// Útil para o frontend verificar quem está logado e exibir o nome/email.
function me(): void {
    // autenticar() valida o token e retorna o ID do usuário,
    // ou encerra a execução com erro 401 se inválido
    $userId = autenticar();

    // Busca os dados do usuário pelo ID (sem a senha_hash por segurança)
    $stmt   = getDB()->prepare('SELECT id, nome, email, criado_em FROM usuarios WHERE id = ?');
    $stmt->execute([$userId]);
    $user = $stmt->fetch();

    // Caso extremamente improvável: usuário autenticado mas não encontrado no banco
    if (!$user) jsonErro(404, 'Usuário não encontrado.');

    // Retorna os dados públicos do usuário
    jsonOk($user);
}

// ─── FUNÇÃO AUXILIAR: gerarToken() ───────────────────────────────
// Cria um novo token de sessão seguro e salva no banco.
// Retorna o token como string hexadecimal de 64 caracteres.
function gerarToken(int $userId): string {
    // random_bytes(32) gera 32 bytes criptograficamente seguros (não previsíveis)
    // bin2hex() converte esses bytes para representação hexadecimal → 64 caracteres
    $token  = bin2hex(random_bytes(32));

    // Define validade de 7 dias a partir de agora
    // modify('+7 days') adiciona 7 dias ao DateTime atual
    // format('Y-m-d H:i:s') formata para o padrão MySQL de DATETIME
    $expira = (new DateTime())->modify('+7 days')->format('Y-m-d H:i:s');

    $db     = getDB();

    // Limpeza preventiva: remove todas as sessões EXPIRADAS deste usuário
    // antes de criar a nova. Mantém o banco limpo sem sessões mortas acumuladas.
    $db->prepare('DELETE FROM sessoes WHERE usuario_id = ? AND expira_em < NOW()')->execute([$userId]);

    // Insere o novo token na tabela sessoes
    $db->prepare('INSERT INTO sessoes (token, usuario_id, expira_em) VALUES (?, ?, ?)')->execute([$token, $userId, $expira]);

    return $token; // Devolve o token para ser enviado ao frontend
}
