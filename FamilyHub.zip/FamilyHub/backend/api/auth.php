<?php
// ============================================
// api/auth.php — Autenticação
// ============================================
// POST /api/auth/login    { email, senha }
// POST /api/auth/cadastro { nome, email, senha }
// POST /api/auth/logout   (Authorization: Bearer <token>)
// GET  /api/auth/me       (Authorization: Bearer <token>)

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../middleware/auth.php';

$sub    = $GLOBALS['sub'];
$method = $GLOBALS['method'];
$body   = $GLOBALS['body'];

if ($method === 'POST' && $sub === 'login')    { login();    exit; }
if ($method === 'POST' && $sub === 'cadastro') { cadastro(); exit; }
if ($method === 'POST' && $sub === 'logout')   { logout();   exit; }
if ($method === 'GET'  && $sub === 'me')       { me();       exit; }

jsonErro(404, 'Rota de autenticação não encontrada.');

// ─── LOGIN ───────────────────────────────────
function login(): void {
    $body  = $GLOBALS['body'];
    $email = trim($body['email'] ?? '');
    $senha = $body['senha'] ?? '';

    if (!$email || !$senha) jsonErro(400, 'E-mail e senha são obrigatórios.');

    $db   = getDB();
    $stmt = $db->prepare('SELECT id, nome, email, senha_hash FROM usuarios WHERE email = ?');
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($senha, $user['senha_hash'])) {
        jsonErro(401, 'E-mail ou senha incorretos.');
    }

    $token = gerarToken($user['id']);

    jsonOk([
        'token'   => $token,
        'usuario' => [
            'id'    => $user['id'],
            'nome'  => $user['nome'],
            'email' => $user['email'],
        ]
    ]);
}

// ─── CADASTRO ─────────────────────────────────
function cadastro(): void {
    $body  = $GLOBALS['body'];
    $nome  = trim($body['nome']  ?? '');
    $email = trim($body['email'] ?? '');
    $senha = $body['senha'] ?? '';

    if (!$nome || !$email || !$senha) jsonErro(400, 'Nome, e-mail e senha são obrigatórios.');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) jsonErro(400, 'E-mail inválido.');
    if (strlen($senha) < 6) jsonErro(400, 'A senha deve ter ao menos 6 caracteres.');

    $db = getDB();
    $check = $db->prepare('SELECT id FROM usuarios WHERE email = ?');
    $check->execute([$email]);
    if ($check->fetch()) jsonErro(409, 'E-mail já cadastrado.');

    $hash = password_hash($senha, PASSWORD_BCRYPT);
    $db->prepare('INSERT INTO usuarios (nome, email, senha_hash) VALUES (?, ?, ?)')->execute([$nome, $email, $hash]);
    $userId = (int) $db->lastInsertId();

    $token = gerarToken($userId);

    jsonOk([
        'token'   => $token,
        'usuario' => ['id' => $userId, 'nome' => $nome, 'email' => $email]
    ], 201);
}

// ─── LOGOUT ───────────────────────────────────
function logout(): void {
    $headers = getallheaders();
    $auth    = $headers['Authorization'] ?? $headers['authorization'] ?? '';
    if (str_starts_with($auth, 'Bearer ')) {
        $token = trim(substr($auth, 7));
        getDB()->prepare('DELETE FROM sessoes WHERE token = ?')->execute([$token]);
    }
    jsonOk(['mensagem' => 'Sessão encerrada.']);
}

// ─── ME ───────────────────────────────────────
function me(): void {
    $userId = autenticar();
    $stmt   = getDB()->prepare('SELECT id, nome, email, criado_em FROM usuarios WHERE id = ?');
    $stmt->execute([$userId]);
    $user = $stmt->fetch();
    if (!$user) jsonErro(404, 'Usuário não encontrado.');
    jsonOk($user);
}

// ─── HELPER: cria sessão e retorna token ──────
function gerarToken(int $userId): string {
    $token  = bin2hex(random_bytes(32));
    $expira = (new DateTime())->modify('+7 days')->format('Y-m-d H:i:s');
    $db     = getDB();

    // Remove sessões expiradas do usuário
    $db->prepare('DELETE FROM sessoes WHERE usuario_id = ? AND expira_em < NOW()')->execute([$userId]);

    $db->prepare('INSERT INTO sessoes (token, usuario_id, expira_em) VALUES (?, ?, ?)')->execute([$token, $userId, $expira]);
    return $token;
}
