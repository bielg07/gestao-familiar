<?php
// ============================================
// config/db.php — Conexão MySQL com PDO
// ============================================
// Este arquivo centraliza TODAS as configurações de conexão com o banco.
// É incluído por todos os outros arquivos PHP do backend via require_once.

// ─── CONSTANTES DE CONFIGURAÇÃO ───────────────────────────────────
// define() cria constantes globais: disponíveis em qualquer lugar do código,
// não podem ser alteradas após definidas (diferente de variáveis $).

define('DB_HOST', 'localhost');   // Endereço do servidor MySQL (neste caso, a própria máquina)
define('DB_NAME', 'familyflow'); // Nome do banco de dados que será usado
define('DB_USER', 'root');        // Usuário MySQL com acesso ao banco
define('DB_PASS', 'Senai@118');   // Senha do usuário MySQL
define('DB_PORT', 3306);          // Porta padrão do MySQL (3306)

// ─── FUNÇÃO: getDB() ──────────────────────────────────────────────
// Retorna uma instância PDO (PHP Data Objects) de conexão com o banco.
// PDO é a forma moderna e segura de se conectar ao banco em PHP:
// suporta prepared statements que previnem SQL Injection.
function getDB(): PDO {

    // Padrão Singleton: a variável $pdo é "static", ou seja,
    // mantém seu valor entre chamadas da função.
    // Na primeira chamada, $pdo é null e a conexão é criada.
    // Nas chamadas seguintes, reutiliza a conexão já existente
    // (evita abrir múltiplas conexões desnecessárias).
    static $pdo = null;
    if ($pdo !== null) return $pdo;

    // DSN (Data Source Name): string de configuração do PDO
    // Formato: "mysql:host=HOST;port=PORTA;dbname=BANCO;charset=CHARSET"
    // sprintf() substitui os %s e %d pelos valores das constantes definidas acima
    $dsn = sprintf(
        'mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4',
        DB_HOST, DB_PORT, DB_NAME
    );

    try {
        // Cria a conexão PDO com as credenciais e opções de comportamento
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            // ERRMODE_EXCEPTION: lança uma PDOException em caso de erro
            // (em vez de retornar false silenciosamente — facilita detectar bugs)
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,

            // FETCH_ASSOC: ao buscar registros, retorna arrays associativos
            // Ex: ['id' => 1, 'nome' => 'Ana'] em vez de [0 => 1, 1 => 'Ana']
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,

            // Desativa prepared statements emulados pelo PHP.
            // Com false, os prepared statements são executados DIRETAMENTE pelo MySQL,
            // garantindo maior segurança e tipos de dados corretos.
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
    } catch (PDOException $e) {
        // Se a conexão falhar (banco offline, credenciais erradas, etc.),
        // chama a função jsonErro() definida em index.php
        // e retorna HTTP 500 (Internal Server Error) com mensagem amigável.
        // A mensagem real do erro ($e->getMessage()) NÃO é exposta ao usuário por segurança.
        jsonErro(500, 'Falha na conexão com o banco de dados.');
    }

    return $pdo; // Retorna a conexão criada para ser usada pelas outras funções
}
